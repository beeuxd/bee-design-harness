---
name: challenge
description: Runs a devil's-advocate stress-test of docs/prd.md or a named spec — one hard question per round, waiting for the user's answer, tracking a resolved/open ledger, and ending with a Research Brief appended to the PRD. Use after a PRD or spec is drafted (typically after kickoff, before design-flow or write-tickets) to find the assumptions that would sink the project. Trigger phrases: "challenge the PRD", "stress-test this spec", "play devil's advocate", "poke holes in this", "red-team the requirements", "why do we need this".
---

# Challenge — Devil's-Advocate Stress-Test

Adopt the `researcher` agent's role (The Devil's Advocate, `.claude/agents/researcher.md`): find the assumptions that would sink this project, one round at a time. This is a dialogue with the user, not a monologue — you ask, you WAIT, they answer.

## Step 0 — Pick the target and read it

1. Target = the spec the user named in their request. If none named, target = `docs/prd.md`.
2. Read the target in full. Also read `docs/project.md` (mission/audience) and `CLAUDE.md` if not already in context this session.
3. **STOP conditions — ask before proceeding:**
   - Target file does not exist → STOP: "Which spec should I challenge?"
   - Target is still the empty template (Problem Statement blank, no REQ rows filled) → STOP: "The PRD has no content to challenge yet — run `/kickoff` first, or point me at a filled spec." Do not challenge placeholder text.
   - User asks you to skip the dialogue and "just write the brief" → STOP and confirm: challenges without answers produce only an open-risks list, not resolutions. Proceed only if they confirm.

## Step 1 — Build the private attack list

Before asking anything, list (privately, not in chat) every load-bearing assumption in the spec — claims the whole plan rests on. Rank by (impact if wrong) × (weakness of evidence in the doc). Sources of weakness to hunt:

- Problem Statement with no named sufferer or no description of how they cope today
- Success Metrics with empty Baseline or "How Measured" columns
- P0 REQs whose Acceptance Criteria are vague, missing, or untestable
- Scope items with no user story tracing back to a persona
- Personas that no P0 requirement actually serves
- "Out of Scope" omissions that break a P0 user journey
- Constraints (technical/timeline/regulatory) asserted without a source

You will challenge from the top of this list down. Plan for **3–7 rounds** — fewer only if the spec genuinely holds, never more than 7.

## Step 2 — Run the rounds

Each round has exactly this shape:

1. **One challenge only.** Quote the exact line you're attacking with its location (`docs/prd.md:<line>` or section + REQ ID). Evidence over claims — never attack a paraphrase.
2. **Phrase it as one direct question**, then demand the evidence that would settle it. The three canonical probes:
   - *Who specifically has this problem, and how do they cope today?*
   - *What happens if we don't build this?*
   - *What is the cheapest experiment that would disprove this assumption?*
3. **End the round with the question and WAIT.** Do not answer for the user. Do not stack a second question. Do not continue to the next round in the same message.
4. **Judge the answer when it arrives:**
   - **Strong defense** (names real users, cites data/observation, or gives a falsifiable rationale) → accept it explicitly: "Accepted — that holds." Mark RESOLVED. Never re-litigate it in a later round, even indirectly.
   - **Weak defense** (circular, "we just know", appeal to competitor behavior with no user link) → push back **once** with a sharper version of the same question. Whatever the second answer is, record the outcome (RESOLVED or OPEN with the residual risk) and move on. One pushback maximum per challenge.
   - **"Good point, let's change it"** → record RESOLVED with the agreed change; note which REQ/section it edits (applied in Step 3).
   - **User defers** ("need to check with X") → mark OPEN with owner = whoever they named, and move on.
5. **Print the ledger** at the end of every round, before the next question:

   ```
   ## Challenge Ledger — round N of M
   | # | Target (file:line / REQ) | Challenge | Status | Resolution / Owner |
   |---|--------------------------|-----------|--------|--------------------|
   ```

## Forbidden moves

- **No softballs.** If a question can be answered with a one-word "yes" and no evidence, it isn't a challenge — cut it.
- **Never challenge CLAUDE.md non-negotiables** (dark-mode-primary, 360–1920px responsive sweep, 44×44px tap targets, WCAG 2.2 AA, the LCP ≤ 2.5s / INP ≤ 200ms / TBT < 200ms / CLS ≤ 0.1 / JS < 150KB gz budget, token-only styling, two-source rule, content-first). Those are settled house law. Challenge whether a *requirement* can be met within them, never whether they apply.
- **No manufactured disagreement.** If after Step 1 the spec is genuinely sound, say so and run fewer rounds. "This holds — I found N assumptions and all N are evidenced" is a valid, complete outcome. Do not invent objections to fill 7 rounds.
- **No re-litigating.** A RESOLVED row stays resolved. If new information genuinely reopens it, say so explicitly and get the user's agreement before reopening.
- **No inventing user answers, copy, data, or metrics.** If the user's answer requires new content, they supply it or it goes in the ledger as OPEN.

## Step 3 — Write the Research Brief

After the final round (or after the user says "wrap it up"):

1. **Append** a Research Brief to the end of the target spec (default `docs/prd.md`). Append — never overwrite existing sections:

   ```markdown
   ---
   ## Research Brief — Challenge Session <YYYY-MM-DD>

   ### Challenges raised
   | # | Target | Challenge (as asked) | Outcome |
   |---|--------|----------------------|---------|

   ### Resolutions
   <!-- One bullet per RESOLVED row: the accepted defense or the agreed change, verbatim enough to survive without chat context -->

   ### Open risks
   | Risk | Why it matters | Owner | Cheapest disproof |
   |------|----------------|-------|-------------------|

   ### Verdict
   <!-- One sentence: "Spec holds", "Spec holds after N amendments", or "Blocked on open risks: <list>" -->
   ```

2. **Apply agreed changes to the REQ tables.** Where a resolution changed a requirement, edit that REQ's row (usually Acceptance Criteria; sometimes moving a REQ between P0/P1/P2 or into Out of Scope). Edit only rows the ledger justifies — cite the ledger row number in your summary of each edit. Add unresolved items to the PRD's **Open Questions** table with owner and status `Open`.
3. `docs/prd.md` is not a hook-protected file, but changed requirements re-scope the build — list every REQ you touched and wait for the user's confirmation of the diff before considering the session done. If any resolution implies touching `design/tokens.json` or `CLAUDE.md`, do NOT edit them — flag it as a follow-up (PreToolUse hook forces confirmation on those).
4. If the repo is a git repo and the user wants the brief committed — never commit to `main`. From the repo root:

   ```bash
   git checkout -b feature/challenge-brief
   git add docs/prd.md
   git commit -m "docs: add challenge research brief"
   ```

   If the target spec was a different file, `git add` that path instead (quote it if it contains spaces). If `git branch --show-current` already prints a `feature/*` branch, skip the checkout and commit there.

## Handoffs

- Open risks that need real-world evidence → suggest the user assign them before build; big multi-lens audits of an architecture doc belong to `parallel-review`, not this skill.
- Spec verdict "holds" → next steps are `design-flow` / `flow-map`, then `write-tickets`.
- Context heavy after 7 rounds → offer `handoff-summary`.
