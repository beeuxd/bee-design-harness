---
name: flow-map
description: Maps a complete user flow (happy path, branches, errors, edge cases, screens touched) for a feature or REQ-ID from docs/prd.md and writes it into docs/user-flows.md. Use when the user says "map the flow", "user flow for REQ-###", "what's the journey for X", "flow diagram for signup", "how does the user get from A to B", or "document this flow". Produces a portable text diagram plus per-screen state coverage notes; routes to kickoff if the PRD is empty.
---

# Flow Map

Map one user flow end-to-end and record it in `docs/user-flows.md`. Output only touches that one file. Do NOT write code, create pages, or modify any other file.

## Step 1 — Resolve the requirement

1. Read `docs/prd.md` in full.
2. Resolve the argument:
   - **REQ-ID** (e.g. `REQ-003`): find that exact row in the Requirements tables. If the ID does not exist, STOP and ask the user which requirement they meant — list the IDs that do exist.
   - **Feature name**: collect every requirement row whose text relates to it. Quote the matched IDs back (e.g. "Mapping REQ-002, REQ-005") so the user can correct scope before you proceed.
   - **No argument**: ask the user which feature or REQ-ID to map. Do not guess.
3. If `docs/prd.md` has no filled-in requirements (template tables are empty), STOP. Tell the user: "The PRD is empty — run `/kickoff` first to define requirements, then re-run `/flow-map`." Do not invent a flow from nothing.
4. Also read `docs/user-flows.md`. Note whether a section for this flow already exists (you will replace it, not duplicate it) and which other flows exist (for cross-flow connections in Step 4). If the file does not exist yet, note that — Step 4 tells you how to create it.

## Step 2 — Map the flow

Restate the user goal in **one sentence** ("As a [persona], I want to [action] so that [outcome]" — lift the persona and outcome from the PRD user story; never invent them). Then map, in order:

1. **Entry points** — every way the flow can start: primary CTA, nav link, deep link/shared URL, notification, redirect from another flow. If the PRD doesn't say where the flow starts, ask — don't assume a homepage button.
2. **Happy path** — numbered steps from trigger to success state. Each step names: what the user does, which screen they're on, what they see, and the CTA label if the PRD provides copy. If copy is missing, write `[copy needed: …]` — never invent marketing copy (content-first rule).
3. **Decision points** — every fork gets both branches, each leading somewhere concrete (a later step, another flow, or an exit).
4. **Error and edge branches** — cover at minimum, marking any that don't apply as `N/A — <reason>`:
   - Action failure (server error, validation failure) and its recovery path
   - Empty state (no data yet — first-time user)
   - Slow network / timeout (what does the user see after 3s?)
   - Back-button at each step (data preserved or lost? re-submission risk?)
   - Deep-link entry mid-flow (unauthenticated, missing prerequisite state)
   - Returning user re-entering a partially completed flow
5. **Exit points** — where the user lands on success, on abandonment, and on unrecoverable error.
6. **Screens touched** — the deduplicated list of every screen/page the flow passes through.

Format the flow as an indented text diagram inside a fenced code block (portable in any markdown viewer — no Mermaid, no images):

```
1. User clicks [entry CTA] on [screen A]
   -> Sees [screen B]: [primary content]
   -> CTA: [action label]

2. User submits [thing]
   [? Valid input]
   |-- Yes -> Step 3
   |-- No  -> Inline errors on [screen B], focus moves to first invalid field
   [! Network timeout] -> Loading state >3s -> retry affordance, input preserved

3. User reaches success
   -> Sees [confirmation]
   -> Exit: [next screen or flow]
```

Conventions: `->` what appears next, `[? ...]` decision point, `[! ...]` error/edge branch, `|--` branch arm.

## Step 3 — State coverage per screen

For every screen in the "Screens touched" list, add one coverage row stating which of **empty / loading / error / success** states apply, with a reason for any that don't:

| Screen | Empty | Loading | Error | Success |
|---|---|---|---|---|
| [Screen B] | Yes — no items on first visit | Yes — fetch on entry | Yes — fetch + submit failures | Yes — confirmation banner |

No screen ships unlisted. This table is what `review-ux` and `e2e-test` build against later.

## Step 4 — Write to docs/user-flows.md

Update `docs/user-flows.md` and nothing else:

0. **If the file doesn't exist**, create it with exactly this skeleton, then continue: an H1 (`# User Flows`), a `## Flow Inventory` table (columns: Flow | Trigger | Happy-path steps | Edge cases | Status), a `## Cross-Flow Connections` section, and a `## Flow Template` section listing the headings from point 1 below.
1. **One section per flow.** Follow the "Flow Template" structure already in the file (User goal, Entry point, Happy Path, Error States, Edge Cases, Responsive Behavior) and add the Step 3 state-coverage table. Fill the Responsive Behavior rows with what actually changes at 360–767 / 768–1023 / 1024–1439 / 1440–1919 / 1920+ (layout, nav pattern, CTA placement) — the same five-width sweep as the project's responsive non-negotiable; write `No change` where true — don't leave cells blank.
2. **Replace, don't append.** If a section for this flow already exists, replace it in place. Never leave two versions of the same flow in the file.
3. **Update the Flow Inventory table** at the top: flow name, trigger, happy-path step count, edge-case count, status (`Mapped`).
4. **Update Cross-Flow Connections** if this flow enters from or exits into another mapped flow.
5. Tag the section with the requirement IDs it covers (e.g. `Covers: REQ-002, REQ-005`) so drift against the PRD is detectable later.

`docs/user-flows.md` is not a protected file, but keep the edit surgical — do not restructure other flows' sections.

## Step 5 — Report

Reply with:

1. The one-sentence user goal.
2. The flow diagram (the code block from Step 2).
3. Screens touched + state coverage table.
4. Open questions — anything the PRD left ambiguous (missing copy, undefined error behavior, unstated entry points). If any open question blocks the happy path itself, say so explicitly and ask before treating the flow as final.
5. Suggested next step: `/design-flow` to design the screens, or `/write-tickets` if specs are ready.

## Guardrails

- Evidence over claims: every requirement you map cites its REQ-ID, with a `docs/prd.md` file:line reference when a branch depends on exact PRD wording; every assumption is labeled as one.
- Never invent copy, personas, or metrics — flag gaps with `[copy needed]` / `[undefined in PRD]`.
- If the feature implies a new page not in `docs/prd.md`, STOP and ask before adding it to the flow (house rule: new pages require approval).
- Stuck resolving scope after 2 attempts → follow `escalation-protocol`.
