---
name: kickoff
description: Runs the PM discovery protocol for a new feature or project — asks one batch of structured discovery questions, waits for answers, then writes numbered, testable requirements into docs/prd.md. Use when the user says "kick off", "new feature", "scope this feature", "write a PRD", or "requirements for X". Produces REQ-IDs with acceptance criteria, an explicit out-of-scope list, and open questions; ends by proposing the challenge skill. (Opening or resuming a chat session — "let's get started", "pick up where we left off" — is session-start; this skill scopes new product work, not the session.)
---

# Kickoff — PM discovery → PRD

Turn a fuzzy feature idea into testable requirements in `docs/prd.md`. You are acting as the `pm` agent: ask, listen, write. Never invent answers.

## Step 0 — Orient

1. Read `docs/project.md` (mission, audiences) and `docs/prd.md` (existing requirements). If neither exists or both are empty templates, this is a brand-new project — say so and continue; the answers below will seed them.
1b. **Research check:** read `docs/ideation/feature-tree.md` and `docs/research/problems.md` if they exist. A filled feature tree seeds this kickoff: Must/Should FEAT rows become P0/P1 candidates (cite FEAT-IDs in the REQ rows), the validated problem statement seeds the PRD's Problem Statement, and discovery question 1 is already answered — say so and skip it. If neither exists, proceed with discovery as below, and mention once that `/insight-loop` → `/problem-loop` → `/ideation-loop` is the evidence-first path when research material exists.
2. Note the highest existing REQ number in `docs/prd.md` so new IDs continue the sequence (e.g. last is REQ-007 → start at REQ-008).
3. If the feature was named in the invocation (e.g. `/kickoff dark-mode toggle`), use it. If not, ask what we're kicking off as part of the question batch below.

## Step 1 — Discovery questions (ONE batch, then WAIT)

Ask ALL of these in a single message, numbered, adapted to the feature. 3–5 questions total — merge or drop only where `docs/project.md` already answers one (say which doc answered it and quote it).

1. **Problem + severity:** What problem does this solve? Who has it, how often, and what do they do today instead?
2. **Users + context:** Who is the primary user? Where and on what device are they when this matters? (Remember: mobile 360px is a first-class context here, not an afterthought.)
3. **Success metric:** How will we know it worked? What single metric moves, from what baseline to what target?
4. **MVP scope:** What is the smallest version worth shipping — and, explicitly, what is OUT of scope for v1?
5. **Risks + assumptions:** What could go wrong? What are we assuming about users, data, or tech that we haven't verified?

**Hard rules:**
- STOP after asking. Do not answer your own questions. Do not proceed on guesses, "reasonable defaults", or inferred answers.
- If the user answers only some questions, proceed with what you have — every unanswered question becomes a row in the PRD's **Open Questions** table, never an invented fact.
- If an answer contains copy/wording for the UI, treat it as source material. If it doesn't, do NOT write marketing copy into requirements — flag missing copy as an open question (content-first rule).

## Step 2 — Conflict check (STOP conditions)

Before writing anything, compare the answers against the existing `docs/prd.md`:

- **If an answer contradicts an existing requirement** (changes its behavior, scope, or acceptance criteria): STOP. Show both side by side — the existing REQ-ID with its text, and the new answer — and ask: "Keep REQ-0XX, replace it, or split into a new requirement?" Never silently overwrite or soft-merge.
- **If the scope implies a new page/route not already in `docs/prd.md`**: STOP and ask before adding it (house rule: "Stop and ask me before adding a new page not in docs/prd.md").
- **If the scope implies a new dependency, analytics, or third-party embed**: flag it now as an open question — those need explicit approval later.

## Step 3 — Draft requirements (present before writing)

Draft the requirements and show them in chat for approval BEFORE touching `docs/prd.md`:

- **Numbered REQ-IDs** continuing the existing sequence (REQ-008, REQ-009, …). IDs are permanent — never renumber existing ones.
- **Priority tiers:** P0 (launch blocker) / P1 (should have) / P2 (post-launch), matching the tables already in `docs/prd.md`.
- **User story** per requirement: "As a [persona from docs/project.md], I want to [action], so that [outcome]." Use real personas from the docs; if none exist yet, use the persona the user just described.
- **Testable acceptance criteria** per requirement. "Testable" means a reviewer can answer pass/fail with evidence — a screenshot, a Playwright assertion, or a file:line. "Works well" and "feels fast" are not criteria.

**Standard gates — include in the acceptance criteria of every UI-facing requirement (verbatim or tightened, never omitted):**
- Renders correctly at 360 / 768 / 1024 / 1440 / 1920px (evidence: `visual-qa` screenshots — its default run covers 360/768/1440; capture 1024 and 1920 additionally so all five widths are evidenced).
- WCAG 2.2 AA: keyboard reachable, visible focus, contrast AA, `prefers-reduced-motion` respected; tap targets ≥ 44×44px (evidence: `a11y-audit`).
- Dark mode is the primary theme; designed and verified dark-first.
- Token-only styling from `design/tokens.json` — no hardcoded hex, no arbitrary px (evidence: `design-system-audit` clean).
- Performance budget holds on mid-tier mobile: LCP ≤ 2.5s, INP ≤ 200ms, TBT < 200ms, CLS ≤ 0.1, JS first-load < 150KB gzipped (evidence: `performance-check`). Fail = no ship.

Also draft:
- **In scope (v1)** and **Out of scope (v1)** lists — out-of-scope items come from the user's Step 1 answer plus anything they deferred; label each with why it's out.
- **Open Questions** table rows: question, owner, status `Open` — one per unanswered discovery question or flagged unknown.
- **Success Metrics** row(s): metric, baseline, target, how measured. If the user gave no baseline, baseline = "unknown — measure first" (open question), not a made-up number.

Wait for explicit approval ("yes", "ship it", edits applied) before Step 4.

## Step 4 — Write docs/prd.md

1. Update `docs/prd.md` following its existing table structure (Problem Statement, Target Users, Success Metrics, Requirements P0/P1/P2, Scope, Constraints, Open Questions). Extend tables; do not delete existing rows unless the user approved a replacement in Step 2.
2. If `docs/project.md` is still an empty template and the answers covered mission/audience, offer to seed it — ask first, don't just do it.
3. Do NOT edit `design/tokens.json` or `CLAUDE.md` from this skill — both are protected files (PreToolUse hook); kickoff has no business touching them.
4. If you're committing docs, check the current branch first: `git branch --show-current`. If it prints `main`, create a feature branch before committing — name it `feature/` + a short kebab-case slug of the feature + `-prd`, e.g. `git checkout -b feature/dark-mode-prd`. Commit with the conventional `docs:` prefix, e.g. `git commit -m "docs: add REQ-008 to REQ-012 to prd.md"`. Never commit to `main`.
5. Confirm the write with the exact section headings and REQ-ID range added (e.g. "Added REQ-008–REQ-012 under P0, 3 open questions").

## Step 5 — Hand off

End with exactly this proposal:

> PRD updated with REQ-0XX–REQ-0YY. Next: run `/challenge` to stress-test these requirements before design — it plays devil's advocate on the assumptions we just wrote down. After that, `/design-flow` designs the experience.

Do not start challenge, design, or implementation yourself. Kickoff ends at the PRD.

## Failure modes to avoid

- Answering your own discovery questions "to save time" → the PRD becomes fiction. WAIT.
- Writing acceptance criteria that can't fail → every criterion needs an evidence source.
- Silently rewriting an existing REQ because the new answer "clearly supersedes it" → Step 2 STOP.
- Adding pages, dependencies, or copy the user never mentioned → ask or log as open question.
- Renumbering REQ-IDs → they are referenced by tickets (`write-tickets`) and tests (`e2e-test`); IDs are append-only.
