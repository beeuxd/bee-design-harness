---
name: design-options
description: Generates 3 genuinely distinct design variants along one named variance axis, builds each on a throwaway scratch route, screenshots all of them dark at 1440 and 360px, and presents them side-by-side with a recommendation so the user picks the direction. Use when starting a new hero or section pattern, a new page archetype, when the art direction allows multiple layout families, or when the user asks for choices — not when a direction is already fixed, for small components, or for fixes. Trigger phrases — "show me options", "give me a few directions", "design options", "which layout should we use", "explore some variants", "I'm not sure how this section should look". (Writing the full implementable spec for a chosen direction is design-flow; specing a single PRD requirement is prd-to-ui — this skill only compares visual directions so one can be picked.)
---

# Design Options — Parallel Ideation Inside the System

The antidote to one-shot sameness: build 3 real, distinct variants, screenshot them, let the user pick. Variance lives **within** the design system — tokens, art direction, and taste rules bind all three. This skill produces a decision, not shipped code: scratch routes are always deleted afterward.

## Step 0 — Should this skill run at all?

| Situation | Action |
|---|---|
| New hero / new section pattern with no precedent in the codebase | Run this skill |
| New page archetype (first pricing page, first blog index, etc.) | Run this skill |
| Art direction in `docs/design-system.md` names multiple allowed layout families | Run this skill |
| User explicitly asks for options/directions/variants | Run this skill |
| Direction already specified by the art direction or a file in `design/references/` | Do NOT run — just build it (`from-figma` or `new-site-component`) |
| Small component (button, badge, card tweak) | Do NOT run — `new-site-component` |
| Bug fix, copy change, refactor | Do NOT run |

If you're mid-way through this skill and realize the direction was already decided, say so and switch to building the decided direction.

## Step 1 — Preflight gates

1. `docs/design-system.md` must contain a written art direction section. If it doesn't exist or has no art direction, **STOP** — tell the user to run `/art-direction` first. No visual build without it.
2. Read `design/taste-rules.md` in full — every standing rule binds all 3 variants. If the file doesn't exist yet, note "no taste rules on file yet" in your presentation and continue.
3. List `design/references/`. Each variant must cite which reference (or which art-direction section, if references are empty) it follows.
4. Confirm real copy exists for the section (from `docs/prd.md`, existing pages, or the user). If copy is missing, **STOP and ask** — never invent marketing claims, not even for throwaway variants.
5. `git branch --show-current` — must print a `feature/...` branch, never `main`. If it prints `main`, create a branch now: kebab-case the section name yourself and run it, e.g. `git checkout -b feature/hero-options` (pattern: `feature/<section>-options`).

## Step 2 — Define the variance axis BEFORE building

Pick exactly ONE axis and state it in chat before writing any code:

- **Layout family** — e.g. split vs. centered vs. asymmetric grid
- **Density** — airy editorial vs. compact utilitarian vs. middle
- **Type treatment** — display-led vs. body-led vs. mixed-scale
- **Motion character** — static vs. subtle reveal vs. choreographed (must still pass the `motion` skill's reduced-motion gate)

Then write three one-line variant briefs (A/B/C) that differ **along that axis**. Post the axis + briefs before building. If the user named the axis or specific directions, use theirs.

Rule: if two briefs could describe the same screenshot, they are not distinct — rewrite before building.

## Step 3 — Build the 3 variants on scratch routes

Scratch routes live at `/_options/a`, `/_options/b`, `/_options/c`. Next.js App Router treats `_`-prefixed folders as private (never routed), so the folder must use the URL-encoded name `%5F` (Next's official escape for a literal underscore in a route segment):

```bash
mkdir -p "app/%5Foptions/a" "app/%5Foptions/b" "app/%5Foptions/c"
```

Each variant is a `page.tsx` in its folder. Constraints binding ALL variants — this is variance within the system, not against it:

- **Tokens only** — every color/spacing/radius/type value from `design/tokens.json` classes. No hex, no arbitrary px (the `design-system-guard` hook will flag violations — fix them same turn).
- **Art direction respected** — same fonts, palette, and voice per `docs/design-system.md`.
- **Taste rules obeyed** — every rule in `design/taste-rules.md`.
- **Reuse before build** — existing components from `design/components.md` first; a missing primitive comes in via `add-shadcn-component` (two-source rule: visuals restyled to our tokens, interaction behavior kept from shadcn's actual source). Never invent a parallel button.
- **Real copy** — identical copy across all three variants so only design varies.
- Dark mode (the primary theme — build and judge dark-first), WCAG 2.2 AA contrast, 44×44px tap targets, semantic HTML, `prefers-reduced-motion` respected.

**Parallel path (preferred):** launch 3 subagents at once via the Task/Agent tool (agent: `frontend-engineer`). Give each ONE variant brief plus: the axis, its scratch path (`app/%5Foptions/a/page.tsx` etc.), the constraint list above, the copy, and its cited reference. Subagents must not touch each other's folders or any real route.

**Sequential fallback:** if parallel subagents aren't available, build A, then B, then C yourself — write each brief's distinguishing choice as a comment at the top of its `page.tsx` so drift toward sameness is visible.

Scratch hygiene: `app/%5Foptions/` is never committed and never shipped. Add it to `.gitignore` now if absent:

```bash
grep -q '%5Foptions' .gitignore 2>/dev/null || echo 'app/%5Foptions/' >> .gitignore
```

## Step 4 — Screenshot each variant at 1440 and 360, dark

Check for a dev server started under this library's convention: a port in `/tmp/dev-server.log` that responds (`curl -sf "http://localhost:$PORT" > /dev/null`). If none responds, start one now. The command MUST redirect output to `/tmp/dev-server.log` — the port check below reads that file. Run `nohup pnpm dev > /tmp/dev-server.log 2>&1 & echo $! > /tmp/dev-server.pid` (the pid file is how Step 6 stops it — same convention as `parallel-review`); never a plain foreground `pnpm dev`. Read the ACTUAL port from the log per `bootstrap-app` Step 8 — never assume 3000 (Next silently moves to 3001+ and you'd screenshot the wrong app):

```bash
PORT=""
for i in $(seq 1 30); do
  PORT=$(grep -m1 -Eo "localhost:[0-9]+" /tmp/dev-server.log 2>/dev/null | cut -d: -f2)
  [ -n "$PORT" ] && break
  sleep 1
done
[ -n "$PORT" ] && echo "dev server on port $PORT" || echo "NO PORT FOUND — read /tmp/dev-server.log"
```

If `NO PORT FOUND` prints, root-cause from the log before any screenshot. Then capture (`.qa/` is scratch, already gitignored by `visual-qa` convention):

```bash
# Re-derive PORT here — shell variables do NOT survive between Bash tool calls
PORT=$(grep -m1 -Eo "localhost:[0-9]+" /tmp/dev-server.log | cut -d: -f2)
mkdir -p .qa/options
for v in a b c; do
  for size in "1440,900" "360,780"; do
    w=${size%%,*}
    pnpm exec playwright screenshot --viewport-size "$size" --color-scheme dark \
      --full-page --wait-for-timeout 2000 \
      "http://localhost:$PORT/_options/$v" ".qa/options/$v-$w.png"
  done
done
ls -la .qa/options/
```

If a screenshot 404s: verify the folder is literally named `%5Foptions` (not `_options`) and the URL uses `/_options/`. If Playwright errors "Executable doesn't exist": `pnpm exec playwright install chromium`, retry once. If `playwright` itself isn't installed in the project, **STOP and ask** before adding it — new dependencies need approval per CLAUDE.md (projects that have run `visual-qa` or `e2e-test` already have it).

Read all 6 PNGs yourself before presenting. **STOP condition — fake choice:** if the three look alike (a squint test wouldn't tell them apart), say exactly that to the user, do NOT present them as options, and re-run Step 2→4 with a stronger or different axis. Never dress up 3 near-clones as a decision.

## Step 5 — Present side-by-side

Show the user, per variant: the 1440 + 360 screenshots (list the `.qa/options/<v>-<width>.png` file paths so they can open them), a one-line rationale ("A: <how it expresses the axis>, follows <reference/art-direction section>"), then YOUR recommendation with one concrete reason (hierarchy, scanability, fit to a taste rule — not "feels nicer"). Ask the user to pick one or mix ("A's layout with C's type"). Do not proceed without their answer.

## Step 6 — Promote the winner, clean up, capture the WHY

1. Copy the winning variant's code (or the agreed mix) into the real route/component location. Re-verify there with `visual-qa` and the full 360→1920 responsive sweep via `responsive-implementation` — the scratch screenshots are not the shipping evidence.
2. Delete all scratch material and stop the dev server this skill started (skip the kill if a server was already running before Step 4 — then it isn't yours to stop):
   ```bash
   rm -rf "app/%5Foptions" .qa/options
   kill "$(cat /tmp/dev-server.pid)" 2>/dev/null && rm -f /tmp/dev-server.pid
   ```
   Ship gate: `test ! -d "app/%5Foptions" && echo CLEAN` must print CLEAN before `/ship`.
3. Ask the user WHY they chose it (one sentence is enough), then invoke `/taste-retro` with that reasoning so the preference becomes a standing rule in `design/taste-rules.md` — next time, the system already knows.
