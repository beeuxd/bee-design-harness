---
name: debugging-protocol
description: Runs a scientific debugging loop for UI bugs in this stack (Next.js App Router, Tailwind, shadcn/ui) — reproduce, read the real error, test one hypothesis at a time, bisect when lost, fix the root cause, then re-verify. Use whenever a change doesn't render or behave as expected, a fix attempt has already failed once, or an error message is unclear. Trigger phrases: "why isn't this working", "hydration error", "the style isn't applying", "works locally but not in build", "I don't understand this error". (After two failed fix attempts — "still failing", "same error again" — escalation-protocol takes over.)
---

# Debugging Protocol

Purpose: stop guess-and-check. Every fix attempt must be preceded by a written repro, a read error, and ONE named hypothesis. "Compiles" does not mean "renders" — evidence over claims (see CLAUDE.md).

**Hard rule:** after 2 falsified hypotheses on the same bug, STOP changing code and switch to the `escalation-protocol` skill. Do not attempt hypothesis 3 silently.

## Step 1 — Reproduce reliably, then write it down

Do not touch code until you can trigger the bug on demand.

1. Start the app: `pnpm dev` (or `pnpm build && pnpm start` if the bug is build-only — note which). Run it in the background / a second terminal and keep its output readable — Step 2 needs it. In Claude Code, use a background Bash task, not a blocking foreground call.
2. Trigger the bug. Record, verbatim, in your working notes for this session:
   - Exact URL/route and the steps (clicks, input, scroll position).
   - Viewport width (test at 360px first — mobile-first; then the width where it was reported).
   - Theme: dark mode is primary — reproduce in dark first. Note if light-only.
   - Dev vs production build. Cold load vs client navigation.
3. If you cannot reproduce after 3 honest attempts: STOP and ask the user for their exact steps, browser, viewport, and a screenshot. Do not "fix" what you cannot see.

This written repro is the acceptance test for Step 6. Do not lose it.

## Step 2 — Read the ACTUAL error, top to bottom

- Read the full error text, not the first line. The first line is often generic ("Hydration failed"); the second line and the first 2–3 stack frames name the component and file.
- Check ALL three sources — they show different errors:
  1. Terminal running `pnpm dev` (server-side errors, build errors).
  2. Browser console (client errors, hydration diffs, network failures).
  3. The Next.js error overlay. (Human-only UI — you cannot click "Show details". The same information, including the full hydration diff, is emitted to the browser console; capture it with the probe script below.)
- Copy the exact message into your notes. Search the codebase for identifiers it names before searching the web.
- If there is no error at all (silent visual bug): read the broken node's **computed** styles headlessly — that is your "error text". Playwright is already a dependency in this stack. Write this scratch script **at the repo root** (NOT `/tmp` — Node resolves the `playwright` import from the script's own directory upward, so it must sit above the project's `node_modules`); delete before commit. If `playwright` is not in `package.json` but `@playwright/test` is, change the import to `from '@playwright/test'` — it re-exports `chromium`.

  ```js
  // probe.mjs — headless replacement for DevTools; run from repo root with: node probe.mjs
  import { chromium } from 'playwright';
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 360, height: 800 }, colorScheme: 'dark' });
  page.on('console', m => console.log('[console]', m.type(), m.text()));
  page.on('pageerror', e => console.log('[pageerror]', e.message));
  await page.goto('http://localhost:3000/ROUTE'); // <- your repro route
  const result = await page.evaluate(() => {
    const el = document.querySelector('SELECTOR'); // <- the broken node
    if (!el) return 'SELECTOR NOT FOUND';
    const cs = getComputedStyle(el);
    return {
      className: el.className,
      box: el.getBoundingClientRect(),
      // add the properties your hypothesis cares about:
      display: cs.display, position: cs.position, color: cs.color, containerType: cs.containerType,
    };
  });
  console.log(JSON.stringify(result, null, 2));
  await browser.close();
  ```

  Reuse this same script for every "check computed styles" probe below — edit the `evaluate` body per probe.

  Port note: every URL in this skill assumes `http://localhost:3000`. If the dev-server output says it picked another port (3001+ when 3000 was busy), use that port in the probe script and all screenshot commands — probing the wrong port makes a healthy page look broken (`SELECTOR NOT FOUND`, stale content) and sends you chasing a phantom bug.

## Step 3 — One hypothesis, smallest probe

State exactly one hypothesis in one sentence: "I believe X causes Y." Then design the cheapest probe that can prove it FALSE:

- A `console.log` of the actual value at the boundary (server log vs browser log — check both to catch server/client divergence).
- Computed-style check via the Step 2 probe script (is the class present in `el.className`? does the computed value match what the class should set?).
- Hardcode a known-good value temporarily (revert before committing — the token hook will flag hardcoded values; that is correct, probes are not fixes).
- A minimal isolated reproduction: render the component alone on a scratch route (`app/_debug/page.tsx`, delete before commit).

Run the probe. Write the result: hypothesis CONFIRMED or FALSIFIED. Falsified → form hypothesis 2. Falsified twice → `escalation-protocol`. Never run two changes at once; you won't know which one mattered.

## Step 4 — Bisect when lost

If you have no viable hypothesis:

- **Checkpoint first.** Bisecting mutilates the working tree on purpose. Before starting, run the `checkpoint-recovery` skill (or at minimum `git stash push -u -m "pre-bisect probes"` / a WIP commit on your feature branch — never on `main`) so you can restore exactly.
- **Code bisect:** comment out half of the component/page. Bug gone → it's in the removed half; restore and remove the other half to confirm. Recurse until you're staring at ≤10 lines.
- **History bisect:** if it worked before, find the breaking commit. `git bisect` refuses to run on a dirty tree — stash your probes first (and `git stash pop` after `git bisect reset`):
  ```bash
  git bisect start
  git bisect bad                 # current commit is broken
  git bisect good <known-good>   # last commit where the repro passed
  # test each checkout with the Step 1 repro, then:
  git bisect good   # or: git bisect bad
  git bisect reset  # when done
  ```
- Read the diff of the guilty commit/half in full before changing anything.

## Step 5 — Fix the root cause, not the symptom

- Ask "why does this value/state exist?" until you reach a decision, not another symptom. `!important`, a wrapper div that "just makes it work", `suppressHydrationWarning`, or a `setTimeout` are symptom patches — do not ship them without user approval and a comment explaining why.
- The fix must follow house rules: tokens only (`design/tokens.json`), reuse existing components (`design/components.md`, `components/ui/`, `components/site/`), interaction behavior from the shadcn/Radix source (two-source rule).
- If the true fix requires editing `design/tokens.json` or `CLAUDE.md`: STOP and ask the user — these are protected files.
- If the true fix requires a new dependency: STOP and ask the user.

## Step 6 — Prove it

1. Re-run the EXACT Step 1 repro. Screenshot the fixed state (dark mode, at the repro viewport):
   ```bash
   pnpm exec playwright screenshot --viewport-size=360,800 --color-scheme=dark "http://localhost:3000/ROUTE" fixed-360.png
   ```
2. Sweep viewports: 360 / 768 / 1024 / 1440 / 1920px — the fix must not break other widths (repeat the command above per width, changing both `--viewport-size` and the output filename, e.g. `fixed-768.png`, so screenshots don't overwrite each other).
3. Remove all probes: `console.log`s, `probe.mjs`, scratch routes, hardcoded values, commented-out halves. `git diff` and read every hunk before finishing.
4. Run `pnpm lint && pnpm build`.
5. Run the `verify-before-done` skill (or, if absent in this project, the `visual-qa` skill) before reporting done.
6. In your final report, state the root cause with a `file:line` reference, the falsified/confirmed hypotheses, and attach the evidence (screenshots + lint/build output). No file:line, no "fixed".

## Failure-mode table for THIS stack

Check this table BEFORE forming a hypothesis — most UI bugs here are one of these.

| Symptom | Likely cause | Probe |
|---|---|---|
| Hydration mismatch ("Text content does not match" / "Hydration failed") | `Date.now()`, `Math.random()`, `window`/`localStorage`, or locale formatting evaluated during server render | The full hydration diff appears in the browser console — capture it with the Step 2 probe script to find the mismatched node; grep that component for `Date`, `random`, `window`, `Intl`. Fix: move into `useEffect`, or gate render on a `mounted` state — never `suppressHydrationWarning` without approval |
| Tailwind class in JSX but style not applied | Dynamically built class string (`` `text-${color}` ``) — the compiler only sees complete literal class names | Step 2 probe: is the full class name in `el.className` AND does the computed value match what that class should set? Class present but value wrong → the rule was never generated: grep the component for template-literal class construction (e.g. `grep -rn 'text-\${' app/ components/`). Fix: map props to complete literal strings, or use `cva` variants |
| `@sm:`/`@md:` container query does nothing | Parent is missing `@container` | Step 2 probe — in the `evaluate` body, walk up: `let a = el.parentElement; while (a) { if (getComputedStyle(a).containerType === 'inline-size') return a.tagName + '.' + a.className; a = a.parentElement; } return 'NO CONTAINER ANCESTOR';`. Fix: add `@container` to the component's direct parent (see docs/tech.md) |
| Flash of wrong theme on load | Dark class applied after first paint (theme set in `useEffect`/client JS) | Check the server-rendered HTML before any JS runs: `curl -s http://localhost:3000/ROUTE -o /tmp/ssr.html && grep -o '<html[^>]*>' /tmp/ssr.html` — the dark class must already be there. If it only appears in the live DOM (Step 2 probe) but not in the curl output, it's applied client-side. Fix: theme class on `<html>` at server-render time, or a blocking inline script in `app/layout.tsx` before paint |
| Layout shift when an image loads (CLS) | `next/image` missing `sizes`, or missing `width`/`height` (or `fill` without a sized parent) | Step 2 probe on the rendered `<img>`: read `el.getAttribute('sizes')`, `el.width`, `el.height`. To measure the shift, add to the probe before `goto`: `await page.addInitScript(() => new PerformanceObserver(l => console.log('[cls]', JSON.stringify(l.getEntries()))).observe({ type: 'layout-shift', buffered: true }));`. Rules in docs/tech.md "Image Rules" |
| "useState/useEffect only works in a Client Component" / event handler errors | Hook or handler in a Server Component, or a server component imported into a client boundary incorrectly | Read the SECOND line of the error — it names the file. Apply the decision tree in docs/tech.md: state/effects/browser APIs/events → `"use client"`, kept minimal and leaf-level |
| Behavior contradicts the code you're reading; deleted file still "exists"; changes don't appear at all | Stale `.next` build cache | FIRST verify it's really the cache: hard-reload, restart `pnpm dev`, confirm you're editing the file that's actually imported. Only then `rm -rf .next` and restart. This is a legitimate LAST resort, not a first move — if it "fixes" the bug, you still don't know the cause; note it and confirm the bug doesn't return |

## Anti-patterns (do not do these)

- Changing code before reproducing the bug.
- Two simultaneous changes per probe.
- "It builds, so it's fixed" — the repro and screenshot are the proof.
- Restyling around a broken layout instead of finding why it broke.
- Third hypothesis on the same bug instead of `escalation-protocol`.
- Leaving probe code (`console.log`, `_debug` routes, hardcoded hex) in the final diff.
