---
name: responsive-implementation
description: Implements and verifies the project's three-layer responsive system — viewport breakpoints for page layout, container queries for reusable components, clamp() for fluid type — then proves every change at 360/768/1024/1440/1920px with Playwright screenshots. Use when building or fixing any layout, component, or page that must adapt across screen sizes. Trigger phrases: "make this responsive", "fix the mobile layout", "it breaks on tablet", "add breakpoints", "container queries", "clamp the type". (A post-build visual look-over at the standard widths is visual-qa; use this skill when responsive behavior must be built or fixed.)
---

# Responsive Implementation

Build mobile-first, dark-mode-first. Verify with screenshots at every required width. "Compiles" is not evidence — a screenshot is.

## Step 0 — Read before touching code

1. `docs/design-system.md` — type scale, spacing rhythm, breakpoint conventions for THIS project (template values differ per project).
2. `design/patterns.md` — page shell, grid system, responsive stacking table. Reuse these; do not invent new layout patterns.
3. `design/components.md` + `components/ui/` + `components/site/` — if a component that solves this already exists, use it (reuse before build).
4. `design/tokens.json` — token names only; never edit this file without explicit user approval (a PreToolUse hook blocks it).

All sizes, colors, radii come from tokens / the Tailwind scale. No hardcoded hex, no arbitrary px (`w-[347px]` is banned; a PostToolUse hook flags it).

## Choosing the layer — decision rules

- Is this a PAGE-level layout decision (columns of a route, nav swap, section stacking)? → **Layer 1: viewport breakpoints** (`sm:` `md:` `lg:`).
- Is this a REUSABLE component that could render in a sidebar, modal, or full-width main? → **Layer 2: container queries**. Never use `md:` inside a reusable component — it responds to the window, not its slot.
- Is this typography or spacing that should scale smoothly between breakpoints? → **Layer 3: `clamp()`**.
- Unsure whether a component is "reusable"? If it lives in `components/ui/` or `components/site/`, it is. Use container queries.

## Layer 1 — Viewport breakpoints (page layout ONLY)

Mobile-first: base classes are the 360px layout; add larger layouts upward.

```tsx
// app/(site)/page.tsx — page-level grid: viewport breakpoints are correct here
<main className="mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
  <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
```

Rules:
- Base (no prefix) = 360px layout. If you write desktop styles first and "fix mobile later", stop and restructure.
- Follow the stacking table in `design/patterns.md` (hero stacks on mobile, cards 1→2→3 columns, etc.).
- Section rhythm and shell padding come from `design/patterns.md` — do not invent new values.

## Layer 2 — Container queries (EVERY reusable component)

The parent wrapper declares `@container`; children respond with `@sm:` / `@md:` / `@lg:` (Tailwind container-query syntax).

Prerequisite: container queries are built into Tailwind CSS v4. On Tailwind v3 they need the `@tailwindcss/container-queries` plugin in `tailwind.config`. Check `package.json` for the Tailwind version FIRST — on v3 without the plugin, every `@`-prefixed class is generated as nothing and silently does not exist.

```tsx
// components/site/stat-card.tsx — complete working pattern
export function StatCard({ label, value }: StatCardProps) {
  return (
    <div className="@container">
      <div className="flex flex-col gap-2 rounded-lg border border-border bg-card p-4 @md:flex-row @md:items-center @md:justify-between @md:p-6">
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
        <span className="text-2xl font-semibold">{value}</span>
      </div>
    </div>
  );
}
```

**Classic failure — silent no-op.** If the `@container` declaration is missing on an ancestor, every `@sm:`/`@md:` class silently never fires. No error, no warning; the component just stays in its base layout forever:

```tsx
// BROKEN: no @container anywhere above — @md:flex-row never applies
<div className="flex flex-col gap-2 @md:flex-row">
```

If a `@`-prefixed class "does nothing", check for `@container` on the parent FIRST, then the Tailwind version/plugin prerequisite above, before debugging anything else.

Rules:
- The `@container` div is a layout-neutral wrapper; put visual styles on the inner element.
- Nested containers: queries resolve against the NEAREST ancestor container. If a card sits inside a sidebar that is also a container, name them: `@container/card` on the wrapper, `@sm/card:flex-row` on children.
- Grids of components: the grid cell is the container, so each card adapts to its own column width — this is the point.

## Layer 3 — Fluid type and spacing with clamp()

Formula: `clamp(MIN, INTERCEPT + SLOPE*vw, MAX)` where values interpolate linearly between your smallest (360px) and largest (1440px) design widths:

```
slope     = (max − min) / (1440 − 360)        // px per px of viewport
intercept = min − slope × 360                  // px, convert to rem (÷16)
```

Worked example — a heading that is 32px at 360px wide and 48px at 1440px (pull the actual min/max for each role from the type scale table in `docs/design-system.md`; body text stays fixed per that doc):

```
slope     = (48 − 32) / 1080 = 0.0148 → 1.48vw
intercept = 32 − 0.0148 × 360 = 26.67px = 1.667rem
→ font-size: clamp(2rem, 1.667rem + 1.48vw, 3rem);
```

Put clamp() values in a CSS variable or the Tailwind theme (e.g. `--font-size-display` in `app/globals.css` mapped to a utility) — never as an inline arbitrary class with px, which the token hook flags. Use rem in the min/max. Sanity-check the math: the preferred term (`intercept + slope×viewport`) must equal MIN at 360px and MAX at 1440px exactly (example: 26.67 + 0.0148×360 ≈ 32 ✓, 26.67 + 0.0148×1440 ≈ 48 ✓). Beyond 1440 the preferred term keeps growing — that is expected; the MAX argument caps it, which is why the upper bound must be present.

## Tap targets — enforced at every width

- Every interactive element ≥ 44×44px at EVERY tested width, including inside container-query small states. This is the project baseline (stricter than WCAG 2.2 AA's 24px minimum in 2.5.8; we meet AA and then some).
- One allowed exception, straight from WCAG 2.5.8: links inline within a sentence or paragraph. Everything else — buttons, nav items, icon buttons, form controls — must hit 44px.
- Primary CTAs 44–52px tall. shadcn defaults are smaller — restyle the visuals (size, color via tokens), but keep the interaction behavior exactly as shadcn/Radix ships it (two-source rule: visuals from Figma variables → tokens, behavior from shadcn/Radix source). Never ship the default look unchanged.
- Icon-only buttons: pad the hit area (`size-11` = 44px), not just the icon.
- Adjacent targets need ≥ 8px gap so touches don't misfire.

## Test matrix — run for EVERY change

Start the app, then screenshot all five widths in dark mode (dark is the primary theme — verify dark first; light only if the project has enabled it).

`PAGE` = every route the change affects, not just one. Page-level change → that page. Reusable component → every route that renders it (`grep -rln 'ComponentName' app/ --include='*.tsx'`); if that list is longer than ~3 routes, run the full matrix on the 2–3 most representative (most complex usage first) and at least load-check the rest — say which got which treatment in your report. Component not mounted anywhere yet → scratch route `app/_debug/page.tsx`, deleted before commit.

```bash
# 0) One-time: make sure the Playwright browser binary exists (safe to re-run;
#    without it every screenshot command fails with "Executable doesn't exist"):
pnpm exec playwright install chromium

# 1) Already running? 200 → skip steps 2–3.
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000

# 2) Start it detached. A bare `pnpm dev &` dies when the shell call ends:
nohup pnpm dev > /tmp/dev-server.log 2>&1 &

# 3) Poll until ready (~30s max). If this never prints 200, STOP: read
#    /tmp/dev-server.log for the build error and fix it before screenshotting.
curl -s -o /dev/null -w "%{http_code}" --retry 30 --retry-delay 1 --retry-all-errors http://localhost:3000
# If the log says Next.js picked another port (3001 etc.), use that port in every URL below.

mkdir -p .screenshots   # keep out of git: add `.screenshots/` to .gitignore or delete before commit
for W in 360 768 1024 1440 1920; do
  pnpm exec playwright screenshot \
    --viewport-size="$W,900" \
    --color-scheme=dark \
    --full-page \
    "http://localhost:3000/PAGE" ".screenshots/PAGE-$W.png"
done
# Landscape/short viewport (phone rotated) — layouts must not assume tall screens:
pnpm exec playwright screenshot --viewport-size="812,375" --color-scheme=dark \
  "http://localhost:3000/PAGE" ".screenshots/PAGE-812x375.png"
```

Open and LOOK at each screenshot (use the Read tool on the PNG). Check per width: nothing clipped, no overlap, headline line-count sane (2 lines desktop → 6 lines mobile is a fail), spacing rhythm intact, dark theme actually rendering.

Automated hard checks (horizontal scroll at 360px is an automatic fail):

Write the script at the **repo root** (not `/tmp` — Node resolves the `playwright` import upward from the script's own directory, so it must sit above the project's `node_modules`). Delete it before committing. If `playwright` is not in `package.json` but `@playwright/test` is, import from `"@playwright/test"` instead — it re-exports `chromium`.

```bash
cat > resp-check.mjs <<'EOF'
import { chromium } from "playwright";
const url = process.argv[2];
const browser = await chromium.launch();
for (const w of [360, 768, 1024, 1440, 1920]) {
  const page = await browser.newPage({ viewport: { width: w, height: 900 }, colorScheme: "dark" });
  await page.goto(url, { waitUntil: "networkidle" });
  const hscroll = await page.evaluate(() =>
    document.documentElement.scrollWidth > document.documentElement.clientWidth);
  const smallTargets = await page.evaluate(() =>
    [...document.querySelectorAll("a,button,[role=button],input,select,textarea,[tabindex]")]
      .map(el => ({ el, r: el.getBoundingClientRect() }))
      .filter(({ el, r }) => r.width > 0 && r.height > 0 && (r.width < 44 || r.height < 44))
      .map(({ el }) => el.tagName + ":" + (el.textContent || el.ariaLabel || "").trim().slice(0, 30)));
  console.log(w, "hscroll:", hscroll ? "FAIL" : "ok", "| targets<44px:", smallTargets.length, smallTargets.slice(0, 5));
  await page.close();
}
await browser.close();
EOF
node resp-check.mjs "http://localhost:3000/PAGE"   # run from repo root; delete the file before commit
```

Any `hscroll: FAIL` or tap target < 44px must be fixed before you report done, then re-run to prove it. The only findings you may dismiss are links inline within a sentence (the WCAG 2.5.8 exception above) — list each dismissed one with its reason in your report; everything else gets fixed.

## Pitfalls — check these when a layout breaks

- **Hug-content vs fill-container:** children that size to content (`w-fit`, intrinsic width) inside a fluid parent cause lopsided layouts. Reusable components should fill their slot (`w-full`) and let the parent/grid control width.
- **Fixed widths inside fluid grids:** `w-64` inside `grid-cols-3` overflows when the column drops below 256px. Use `min-w-0` on grid/flex children and let the container query restyle instead.
- **Missing `@container`:** see Layer 2 — the number one silent failure.
- **Nested containers resolving against the wrong ancestor:** name them (`@container/name`).
- **Long unbreakable content:** URLs, emails, code force horizontal scroll at 360px. Add `break-words` or `truncate` deliberately.
- **Landscape/short viewports:** `h-screen` heroes and `100vh` modals break at 375px height. Test 812×375; prefer `min-h-` and `dvh` units.
- **Images without dimensions:** cause CLS. Always use `next/image` with explicit sizes.

## STOP and ask the user when

- A design spec exists in Figma but has no layout for one of the five widths — do not invent one; per the two-source rule, visual specs come from Figma variables mapped to tokens, never eyeballed.
- The required layout can't be built without an arbitrary px value or a new token — token changes need explicit approval.
- Fixing responsiveness requires restructuring a page's information architecture (moving/removing sections).
- A component needs a new dependency (e.g. a carousel lib) to be responsive.

## Definition of done — evidence required

- [ ] 5 dark-mode screenshots (360/768/1024/1440/1920) + 1 landscape, visually inspected, paths listed in your report
- [ ] `resp-check.mjs` output pasted: no horizontal scroll at any width; zero tap targets < 44px except explicitly listed inline-text links (WCAG 2.5.8 exception), each with a one-line justification
- [ ] Reusable components use `@container` queries, not `md:`; pages use viewport breakpoints only — cite file:line for each component touched
- [ ] Fluid sizes use clamp() with values traced to `docs/design-system.md`; no hardcoded hex/px
- [ ] Animations added here gated on `prefers-reduced-motion`
- [ ] Performance budget not regressed (LCP ≤ 2.5s, INP ≤ 200ms, CLS ≤ 0.1, JS first-load < 150KB gzipped) — run the project's performance-check skill before shipping; over budget = do not ship
- [ ] Work on a `feature/short-description` branch, never `main`
