---
name: add-shadcn-component
description: Installs a shadcn/ui primitive, restyles every visual aspect to project tokens while leaving its Radix behavioral wiring untouched, and registers it in design/components.md. Use whenever a shadcn component is needed that is not already in components/ui/. Triggers on "add a shadcn [component]", "install the [component] primitive", "we need a Dialog/Select/Tooltip", "add [component] from shadcn", "set up the [component] component".
---

# Adding a shadcn component

Governing rule (the two-source rule): **visual specs come from our tokens, behavior comes from shadcn/Radix.** You restyle appearance only. You never invent interaction behavior and you never eyeball values from screenshots.

## Step 0 — Pre-checks (do all four before installing)

```bash
# 1. Is it on the approved list?
grep -in "<component-name>" design/components.md

# 2. Is it already installed?
ls components/ui/

# 3. Clean working tree, so post-install diffs are attributable
git status --porcelain

# 4. Which branch? (never commit to main)
git branch --show-current
```

Decision rules:
- `design/components.md` missing, empty, or still full of `{{PLACEHOLDER}}` values → **STOP. Ask the user** — there is no approved list to check against.
- Not listed in `design/components.md`, or marked "do not install" → **STOP. Ask the user before adding anything.**
- Already in `components/ui/` → **do not reinstall.** Use the existing file (it is already restyled). Skill ends here.
- Working tree dirty → note which files were already dirty so you don't misattribute changes later.
- On `main` → `git switch -c feature/add-<component-name>` first. Never commit to main.

## Step 1 — Install

First check for `components.json` at the repo root (`ls components.json`). If it is missing, the CLI will launch its interactive `init` flow (writes config, rewrites `globals.css`, adds `lib/utils`) — **STOP and ask the user** before initializing; do not answer init prompts on their behalf. If it exists:

```bash
pnpm dlx shadcn@latest add <component-name>
```

Immediately audit what the CLI touched:

```bash
git status --porcelain
git diff package.json
```

Decision rules:
- New `@radix-ui/*` (or the component's documented peer, e.g. `vaul` for Drawer, `cmdk` for Command) in package.json → expected, proceed. These still count against the JS first-load budget (< 150KB gzipped, see `docs/tech.md`) — if the peer is unusually heavy, say so when showing the diff.
- Any other new dependency → **STOP. Ask the user** (CLAUDE.md: new dependencies require approval).
- The CLI modified an existing file in `components/ui/` you didn't ask for → **revert that file** (`git checkout -- components/ui/<other>.tsx`) unless the user approves the change.

## Step 2 — Restyle visuals to project tokens (source #1)

Default shadcn styling is banned from shipping. Open the new file(s) in `components/ui/` and rework **className strings only**, using values defined in `docs/design-system.md` and `design/tokens.json` (human-readable: `design/tokens.md`). Never hardcode hex or arbitrary px — a PostToolUse hook flags violations at write time.

- [ ] Colors → semantic CSS variables / Tailwind semantic classes (`bg-background`, `bg-primary`, `text-muted-foreground`, `border-border`, ...). No raw hex, no Tailwind palette colors like `bg-zinc-900`.
- [ ] "Primary" variants → primary token for background, primary-foreground for text.
- [ ] Border radius → the project radius scale in `docs/design-system.md` (element size determines which step).
- [ ] Shadows → the project shadow scale only. Remove any default shadows outside it.
- [ ] Focus ring → the project focus-ring treatment defined in `docs/design-system.md`. Replace shadcn's default ring classes; never delete focus-visible styling.
- [ ] Font → inherit from the root layout (fonts are loaded via `next/font`; see `docs/design-system.md`). Remove any hardcoded font-family.
- [ ] Verify dark mode first — dark is the primary theme. Check contrast (WCAG 2.2 AA: 4.5:1 body, 3:1 large text) for every state in dark mode, then light if the project has it.
- [ ] Use logical properties (`ms-*`/`me-*` instead of `ml-*`/`mr-*`) where the original file does.

## Step 3 — Preserve behavior exactly as shipped (source #2)

The primitive's interaction contract is defined by the shadcn/Radix source you just installed. **Do not modify:**

- Radix component structure, props, or composition (`asChild`, `forceMount`, portals, etc.)
- `data-*` attributes and any selectors keyed on them (`data-[state=open]:...` classes stay)
- Event handlers, controlled/uncontrolled wiring, `onOpenChange` etc.
- `aria-*` attributes, roles, focus management, keyboard handling

If a design requirement seems to need behavioral changes to the primitive → **STOP. Ask the user.** That is a wrapper component or a different pattern, not an edit to `components/ui/`.

## Step 4 — Size up to human scale

shadcn defaults are app-scale, not site-scale. Adjust size variants (visual classes only):

- [ ] Every interactive element ≥ 44×44px tap target on touch.
- [ ] Primary CTA-class triggers: 44–52px tall.
- [ ] Animations: confirm existing `data-[state=...]` transitions respect `prefers-reduced-motion`; gate any you add.

## Step 5 — Responsive

- [ ] If the component will be reused across contexts, wrap responsive behavior in `@container` queries — viewport breakpoints are for page layout only; `clamp()` for any fluid type.
- [ ] Renders at 360px without horizontal overflow.
- [ ] Overlay components: Dialog on desktop, Drawer on mobile (see `design/patterns.md` if a pattern exists; otherwise switch on a container/viewport check).
- [ ] Table: needs a horizontal-scroll wrapper or card layout on mobile.

## Step 6 — Verify with evidence ("compiles" ≠ "renders")

```bash
pnpm tsc --noEmit
pnpm dev &   # or use the already-running dev server
# wait until the server responds before screenshotting — bounded, never an infinite loop:
for i in $(seq 1 60); do curl -sf http://localhost:3000 >/dev/null && echo READY && break; sleep 1; done
# no READY after 60s → STOP, read the dev-server output, report the error; do not continue
```

Render the component on the page it's for (or a temporary `app/dev-preview/<component>/` route, matching the `new-site-component` convention — delete it before commit) and capture evidence with Playwright, dark mode first:

```bash
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=360,780   "http://localhost:3000/<route>" /tmp/<component>-360.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=768,900   "http://localhost:3000/<route>" /tmp/<component>-768.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=1024,900  "http://localhost:3000/<route>" /tmp/<component>-1024.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=1440,900  "http://localhost:3000/<route>" /tmp/<component>-1440.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=1920,1080 "http://localhost:3000/<route>" /tmp/<component>-1920.png
```

`--color-scheme=dark` only works when the theme follows `prefers-color-scheme`. Open each PNG; if the background is light, the theme is class-/localStorage-based — capture with the `visual-qa` skill's `.qa/visual-capture.mjs` script instead (it sets the theme via `addInitScript`).

Read the screenshots and check: token colors applied (no default shadcn look), no 360px overflow, tap targets look ≥44px. Then verify keyboard behavior survived the restyle with a quick Playwright script (adapt selectors). Playwright only discovers specs under the `testDir` set in `playwright.config.ts` — check the config first (commonly `e2e/` or `tests/`), write the temp file there, and delete it after:

```ts
// <testDir>/tmp-kbd-check.spec.ts — run: pnpm exec playwright test <testDir>/tmp-kbd-check.spec.ts   (delete the file after it passes)
import { test, expect } from "@playwright/test";
test("keyboard contract intact", async ({ page }) => {
  await page.goto("http://localhost:3000/<route>");
  await page.keyboard.press("Tab");                       // reaches trigger, focus ring visible
  await page.keyboard.press("Enter");                     // activates / opens
  // Overlay components ONLY (Dialog/Drawer/Popover/Select/Menu) — delete the next two lines for anything else:
  await page.keyboard.press("Escape");                    // closes, focus returns to trigger
  await expect(page.locator("[data-state=open]")).toHaveCount(0);
});
```

Required evidence before proceeding — do not claim done without it:
1. Diff of the restyled file (`git diff components/ui/<component>.tsx`) shown to the user **before the component is used anywhere**.
2. Screenshots at 360 / 768 / 1024 / 1440 / 1920 in dark mode (re-sweep all five once it's placed in a real page).
3. Keyboard test passing (tab, enter, escape where relevant).

Any check fails → fix and re-verify. Do not ship a known failure.

## Step 7 — Register

In `design/components.md`:
0. If Storybook is set up (a `storybook` script in `package.json`): write the restyled primitive's story in the same turn via `storybook-component` — the story is the executable proof the restyle covers every state.
1. Set the component's Status/Notes in the shadcn primitives table (note any pattern decisions, e.g. "Drawer on mobile").
2. Add rows to the Figma-to-Code mapping table for each variant/size, mapped to the Figma components in the project's Figma file — its URL is recorded in `design/components.md` itself (grep for `figma.com` there). If that URL is absent or still a `{{FIGMA_URL}}` placeholder, or no Figma component exists yet → note "no Figma counterpart" and flag it to the user; do not invent a mapping.
3. Include a working usage example (repo convention).

`design/components.md` is a normal doc — but `design/tokens.json` and `CLAUDE.md` are protected. If the component seems to need a new token → **STOP. Ask the user** (a PreToolUse hook blocks unapproved edits anyway).

## Forbidden

- Installing a primitive marked "do not install", or one absent from the approved list, without user approval.
- Modifying any other primitive in `components/ui/` as a side effect.
- New dependencies beyond what the shadcn CLI pulls in for this component.
- Editing behavioral wiring (Radix props, data-attributes, handlers, aria, focus management) — visual classes only.
- Shipping default shadcn styling, hardcoded hex, or arbitrary px values.
