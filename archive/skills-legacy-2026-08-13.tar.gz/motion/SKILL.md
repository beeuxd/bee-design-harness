---
name: motion
description: Implements UI animation (transitions, entrances, orchestrated sequences, scroll-driven motion) that passes the project's accessibility gates and performance budget — every animation reduced-motion-gated, transform/opacity only, durations from the motion scale. Use when adding, reviewing, or debugging any animation or micro-interaction. Trigger phrases: "animate this", "add a transition", "entrance animation", "scroll animation", "hover effect", "this animation is janky".
---

# Motion

Motion that ships without wrecking accessibility or performance. Follow every step. If a step conflicts with `CLAUDE.md`, `CLAUDE.md` wins.

## Step 0 — Read the motion scale first

Open `docs/design-system.md` → "Motion Principles" and `design/tokens.md`. All durations and easings come from there — never invent per-component values. If the project defines motion tokens in `design/tokens.json`, use those (token-only styling is enforced by a write-time hook; hardcoded values get flagged).

**STOP and ask the user if:** the motion scale is missing or still contains `{{PLACEHOLDER}}` values. Do not guess durations.

Default guardrails from the design system (verify against the project's own doc):
- Micro-interactions: 150–300ms. Transitions/entrances: 300–500ms.
- `ease-out` for entrances, `ease-in` for exits.
- Animate only to **reveal structure, direct attention, or signal state change**. If the animation is decoration or delays the user, don't build it.

## Step 1 — Pick the tool (decision tree)

1. **Simple state change, ≤2 properties** (hover, focus, open/close fade) → **CSS `transition`**. No JS.
2. **Simple one-shot entrance or simple loop** (fade-up on mount, skeleton shimmer) → **CSS `@keyframes`**.
3. **Orchestrated sequence or scroll-driven work** (staggered timelines, pinning, scrubbing) → **JS library: GSAP (npm package `gsap`) or Motion (npm package `motion` — formerly `framer-motion`)**, nothing else.
   - Check first: `grep -E '"(gsap|motion|framer-motion)"' package.json`. If neither library is installed, **STOP and ask the user** before adding a dependency (`CLAUDE.md` rule). Never install both.
   - With GSAP in React, use `useGSAP` (see the `gsap-react` and `gsap-scrolltrigger` skills). For award-level scroll work, see `awwwards-animations`.

If you reach for a library for something tiers 1–2 can do, go back to tiers 1–2.

## Step 2 — Non-negotiables (apply to every animation)

### 2a. Progressive reduced-motion gate

Define the animation **inside** the no-preference condition. Reduced-motion users must land on the finished static state — never a frozen mid-animation frame, never `opacity: 0`.

CSS gate (exact pattern):

```css
.card { opacity: 1; transform: none; } /* finished state = default */

@media (prefers-reduced-motion: no-preference) {
  .card-enter {
    animation: card-in var(--motion-duration-entrance) var(--motion-ease-out) both;
  }
  @keyframes card-in {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: none; }
  }
}
```

JS gate (exact patterns — one per library):

```tsx
// GSAP
useGSAP(() => {
  const mm = gsap.matchMedia();
  mm.add("(prefers-reduced-motion: no-preference)", () => {
    gsap.from(".item", { y: 12, autoAlpha: 0, stagger: 0.06 });
  });
  // No reduced-motion branch needed: elements simply stay in final state.
}, { scope: containerRef });
```

```tsx
// Motion (import from "motion/react")
import { motion, useReducedMotion } from "motion/react";

function Card() {
  const reduce = useReducedMotion(); // true when prefers-reduced-motion: reduce
  return (
    <motion.div
      // initial={false} renders the finished state immediately — no entrance
      initial={reduce ? false : { opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
    />
  );
}
```

Never `animation: none` as an override of an always-on animation — that pattern leaves `from` states visible. Gate the *definition*, not the removal.

### 2b. Compositor properties only

Animate `transform` and `opacity` **only**. Never `width`, `height`, `top`, `left`, `margin`, `padding`, `font-size`, or `box-shadow` — they trigger layout/paint every frame. To animate size, use `transform: scale()` or the FLIP technique (GSAP `Flip` plugin — see `gsap-plugins`). Height-reveal accordions: use the shadcn/Radix primitive's own animation (two-source rule: interaction behavior comes from the primitive's actual source, not invented).

### 2c. Never animate the LCP element

The hero heading/image is usually LCP. Animating it (fade-in, blur-up) delays LCP and can blow the ≤2.5s budget. If the design calls for a hero entrance, **STOP and tell the user** the LCP element must render immediately; offer to animate surrounding elements instead.

### 2d. No layout shift from animation

Entrances must not push content (CLS ≤ 0.1). Reserve final space; animate `transform`/`opacity` within it.

### 2e. `will-change` sparingly

Only on elements about to animate, removed after. Never blanket-apply. See `gsap-performance` for batching and jank fixes.

## Step 3 — React cleanup

- Every effect that creates tweens, timelines, `ScrollTrigger`s, or `IntersectionObserver`s **must clean up on unmount**: `useGSAP` with `scope` handles GSAP automatically; raw `useEffect` must return a cleanup that calls `tween.kill()` / `st.kill()` / `observer.disconnect()`.
- **StrictMode double-mounts effects in dev.** If an animation runs twice, stacks transforms, or leaves duplicate ScrollTriggers, the cleanup is missing or wrong — fix the cleanup, do not disable StrictMode.
- Scroll listeners: use `ScrollTrigger`/`IntersectionObserver`, never raw `scroll` events with state updates (INP killer).

## Step 4 — Verify (evidence, not claims)

"Compiles" does not mean "renders", and "renders" does not mean "60fps". Run all three passes and report results with evidence: screenshots, the numbers from each check, and a `file:line` reference to the reduced-motion gate of every animation you touched.

All three passes are scriptable with Playwright (already in the stack). Reuse the project's `visual-qa` and `performance-check` skills/scripts before writing a new harness. Steps marked **Human-only** require a person at a browser — never present them as steps you ran.

**1. Performance pass (scriptable).** Prerequisites: serve the **production build** first (`pnpm build && pnpm start` — dev-mode frame timings are not valid evidence). If a dev server already occupies port 3000 (usual after `session-start`), either stop it first (`lsof -ti:3000 | xargs kill`; restart it afterwards if the session continues) or run the prod server on its own port (`PORT=3100 pnpm start`) and point every URL in this pass at that port — measuring the dev server by mistake produces garbage numbers that look like real evidence. Put the spec inside the repo's configured Playwright `testDir` (check `playwright.config.ts`; if it isn't `tests/`, adjust the path below or Playwright reports "no tests found"). Delete the spec before committing unless the user wants it kept. Emulate a mid-tier mobile: 4x CPU throttle via CDP, 360px viewport. Trigger the animation and count dropped frames:

```ts
// tests/motion-perf.spec.ts — run with: pnpm exec playwright test tests/motion-perf.spec.ts
import { test, expect } from "@playwright/test";

test("animation holds 60fps under 4x CPU throttle", async ({ page }) => {
  const cdp = await page.context().newCDPSession(page); // Chromium only
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 }); // mid-tier mobile approximation
  await page.setViewportSize({ width: 360, height: 780 });
  // Use the full URL — a bare "/route" throws unless playwright.config.ts sets baseURL:
  await page.goto("http://localhost:3000/page-under-test");
  // Trigger the animation here (click, scroll into view, etc.), then sample ~2s of frames:
  const longFrames = await page.evaluate(
    () =>
      new Promise<number>((resolve) => {
        let last = performance.now(), long = 0, n = 0;
        const tick = (t: number) => {
          if (t - last > 17) long++; // frame blew the 16.7ms (60fps) budget
          last = t;
          if (++n < 120) requestAnimationFrame(tick);
          else resolve(long);
        };
        requestAnimationFrame(tick);
      })
  );
  expect(longFrames).toBeLessThanOrEqual(1); // target 60fps; 1 frame of startup jitter allowed
});
```

- Budget check: run the project's `performance-check` skill (or Lighthouse) and paste the numbers — LCP ≤ 2.5s, INP ≤ 200ms, CLS ≤ 0.1, TBT < 200ms. **Fail = do not ship.** Fix or remove the animation.
- If a JS library was added: run `pnpm build` and paste the route's "First Load JS" line from the Next.js build output — must stay < 150KB gzipped. GSAP/Motion imports must be tree-shaken or loaded via `next/dynamic` on pages that don't animate.
- **Human-only (optional deep dive):** DevTools → Performance → CPU 4x → record while the animation plays. Purple Layout / green Paint blocks during the animation mean a non-compositor property snuck in.

**2. Reduced-motion pass (scriptable).** In Playwright: `await page.emulateMedia({ reducedMotion: "reduce" })`, reload, screenshot every animated region. The page must be **fully usable**: all content visible in finished state, nothing stuck at `opacity: 0` or off-screen, scroll-driven sections readable without scrubbing. Attach the screenshots. (**Human-only equivalent:** DevTools → Rendering → Emulate `prefers-reduced-motion: reduce`.)

**3. Viewport + theme sweep (scriptable).** Dark mode first (primary theme). Loop `page.setViewportSize()` over **360 / 768 / 1024 / 1440 / 1920px** and screenshot each — extend the `visual-qa` skill's script, which covers 360/768/1440, with 1024 and 1920. Per the design system, prefer simpler or disabled animations on mobile — an animation acceptable at 1440px can still fail the 360px trace.

## Checklist before marking done

- [ ] Duration/easing from `docs/design-system.md` motion scale (or motion tokens) — nothing invented
- [ ] Lowest-tier tool that works (transition → keyframes → library); new dependency approved by user
- [ ] Animation defined inside `prefers-reduced-motion: no-preference` (CSS) or `matchMedia` (JS)
- [ ] Reduced-motion state = finished static state, page fully usable
- [ ] `transform`/`opacity` only; no layout properties
- [ ] LCP element not animated
- [ ] React cleanup kills tweens/triggers/observers; survives StrictMode double-mount
- [ ] 4x-throttled trace at 360px: 60fps, no layout/paint storms
- [ ] Budget intact: LCP ≤ 2.5s, INP ≤ 200ms, CLS ≤ 0.1, TBT < 200ms, JS < 150KB gzipped
- [ ] Verified in dark mode at 360/768/1024/1440/1920px with evidence attached
- [ ] Report cites `file:line` of the reduced-motion gate for each animation
- [ ] Work is on a `feature/*` branch — never commit to `main` (`CLAUDE.md` repo convention)
