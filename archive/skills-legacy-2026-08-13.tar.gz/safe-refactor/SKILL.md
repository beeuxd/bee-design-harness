---
name: safe-refactor
description: Runs a blast-radius protocol before and after any change to shared code — components/ui/, components/site/, lib/, or design tokens — by finding every consumer, checkpointing, capturing before-screenshots, preferring additive changes, and re-verifying all consumers at 360 and 1440px. Use whenever editing a component or module that is imported in more than one place. Trigger phrases: "refactor this component", "change the Button variant", "update this shared component", "rename this prop", "this change might break other pages", "change a token value safely". (Diffing tokens against Figma is design-tokens-sync; this skill governs making a shared-code or token edit without breaking consumers.)
---

# Safe Refactor — Shared Code Change Protocol

Use this protocol for ANY edit to: `components/ui/`, `components/site/`, `lib/`, or `design/tokens.json`.
If the file is used in exactly one place and lives outside those paths, this skill does not apply — edit normally.

Never skip steps because the change "looks trivial". One-line changes to shared code break pages you are not looking at.

## Step 0 — Classify the change first

Decide which bucket the request falls into BEFORE editing:

| Change type | Allowed? |
|---|---|
| New variant, new optional prop, default unchanged | Yes — preferred path |
| New component alongside old one | Yes |
| Visual change with same API (spacing, color token swap) | Yes, with full re-verification |
| Changing a prop's meaning or default value | STOP — ask the user first |
| Removing or renaming an export | STOP — ask the user first |
| Any edit to `design/tokens.json` | STOP — protected file, requires explicit user approval (PreToolUse hook enforces this) |

## Step 1 — Find every consumer

Run before touching anything:

```bash
grep -rn 'ComponentName' --include='*.tsx' app/ components/
```

For `lib/` modules, grep the function/module name instead. Also check re-exports:

```bash
grep -rn "from ['\"].*component-file-name" --include='*.tsx' --include='*.ts' app/ components/ lib/
```

- Write the consumer list into your working notes and show it to the user: file path + line number for each.
- **STOP and ask if there are more than 10 consumers.** Present the blast radius (the full list) and a step-by-step plan; wait for approval before editing.
- Zero consumers found? Re-check your grep pattern (default exports, aliased imports, dynamic imports) before concluding the component is unused.

## Step 2 — Checkpoint commit

Follow the `checkpoint-recovery` skill. Minimum:

```bash
git branch --show-current       # must print a feature/* branch — never main
git add -A && git commit -m "chore: checkpoint before refactor of ComponentName"
git rev-parse HEAD              # record this SHA — it is the recovery point used in Step 5
```

If the branch is `main`, create one first: `git checkout -b feature/short-description`. Never commit to main (CLAUDE.md rule). Write the checkpoint SHA into your working notes.

## Step 3 — Before-screenshots

Pick 2–3 representative consumer pages from the Step 1 list (prefer: the most complex usage, the most trafficked page, and one edge case such as an empty/loading state). No traffic data available (the usual case)? Substitute: the homepage if it consumes the component, otherwise the route the current task is about.

Capture each with Playwright in **dark mode** (primary theme) at 360px and 1440px:

```bash
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=360,800  "http://localhost:3000/PAGE" before-PAGE-360.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=1440,900 "http://localhost:3000/PAGE" before-PAGE-1440.png
```

Replace `PAGE` with the actual route (e.g. `pricing`), and name the files after it. If the dev server is not already running, start it in the background first (`pnpm dev` blocks the terminal — run it as a background task, or `nohup pnpm dev > /tmp/dev-server.log 2>&1 &`) and wait until `http://localhost:3000` responds before screenshotting: `curl -s -o /dev/null -w "%{http_code}" --retry 30 --retry-delay 1 --retry-all-errors http://localhost:3000` must print 200. If the log says Next.js picked another port, use that port in every URL in this skill. Keep the screenshots — they are the comparison baseline in Step 5.

## Step 4 — Make the change (additive first)

Preference order — take the highest one that satisfies the request:

1. **Add a new variant or optional prop with the default unchanged.** Existing consumers compile and render identically without edits.
2. **Add a new component** next to the old one; migrate consumers explicitly, one by one.
3. **Change behavior in place** — only when 1 and 2 genuinely cannot work, and only after telling the user why.

While editing, house rules still apply:
- Token-only styling from `design/tokens.json` — no hardcoded hex, no arbitrary px (a write-time hook flags violations).
- Two-source rule: visual specs from Figma variables mapped to our tokens; interaction behavior from the shadcn/Radix primitive's actual source. Never eyeball, never invent.
- Reuse before build: check `design/components.md`, `components/ui/`, `components/site/` before creating anything new.
- Tap targets >= 44x44px; animations gated on `prefers-reduced-motion`; `@container` queries for reusable-component responsiveness.

## Step 5 — Re-verify EVERY consumer

"Compiles" does not mean "renders". Evidence required:

1. Type-check and build:
   ```bash
   pnpm exec tsc --noEmit && pnpm build
   ```
2. Re-screenshot every page from Step 3 (same commands, including `--color-scheme=dark`, with an `after-` prefix), then open each `before-`/`after-` pair with the Read tool and compare them visually for layout, spacing, and color differences. Dark mode first. 360 and 1440px are the minimum; for visual changes, sweep the full house standard — 360 / 768 / 1024 / 1440 / 1920px (CLAUDE.md non-negotiable) — by repeating the screenshot command with `--viewport-size=768,1024`, `1024,768`, and `1920,1080`.
3. For the remaining consumers on the Step 1 list, at minimum screenshot each affected route with the same Playwright command at 360 and 1440px and confirm no visual regression. If a consumer renders in a state you cannot reach (auth-gated, feature-flagged), say so explicitly — do not claim it was verified.
4. Run existing Playwright tests: `pnpm exec playwright test`. If it reports "no tests found", the project has no suite yet — record "no existing e2e suite" in the Step 5 report and move on; it is not a failure. Actual test failures block the refactor.
5. Report to the user: consumer list, which were screenshot-verified vs. load-verified, and any diffs observed.

If ANY consumer regressed: fix it now, or revert to the Step 2 checkpoint — `git reset --hard <checkpoint-sha>`, using the SHA you recorded in Step 2 (this discards all uncommitted changes) — and report. Never leave a known-broken consumer "for later".

## Step 6 — Update documentation

If the public API changed (new prop, new variant, new component):
- Update `design/components.md` — the component's row, the props/variants notes, and a working usage example (required by CLAUDE.md for every new component).
- If Figma mapping changed, update the "Figma-to-Code Component Mapping" table there too.

If the API did not change, skip this step and say so.

## STOP-and-ask conditions (summary)

Stop and ask the user before proceeding when ANY of these is true:

- [ ] More than 10 consumers — present blast radius + plan first
- [ ] Changing a prop's meaning or its default value
- [ ] Removing or renaming an export
- [ ] Any change to `design/tokens.json` (protected; also protected: `CLAUDE.md`)
- [ ] A consumer cannot be verified (unreachable state, missing fixture) and you would otherwise ship unverified

## Done means

- Consumer list produced and shared
- Checkpoint commit exists on a `feature/*` branch
- Before/after screenshots for 2–3 representative pages, dark mode — 360 and 1440px minimum, full 360/768/1024/1440/1920 sweep for visual changes
- Every consumer re-verified or explicitly flagged as unverifiable
- `design/components.md` updated if the API changed
- No token violations, no regressions, evidence posted — not claims
