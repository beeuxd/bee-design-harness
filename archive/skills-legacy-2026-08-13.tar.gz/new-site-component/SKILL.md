---
name: new-site-component
description: Creates a bespoke (non-shadcn) component under components/site/ — heroes, cards, sections, custom widgets — with a mandatory reuse-first search, two-source specs (Figma tokens + shadcn source), token-only styling, container-query responsiveness, and screenshot evidence at 360/768/1440 before use. Use it whenever a new visual building block is needed and no existing primitive or site component covers it (installing a named shadcn primitive like Dialog or Select is add-shadcn-component, not this). Triggers: "create a custom component", "build a hero section", "make a card component", "new section component", "build a custom widget", "add a testimonial block".
---

# New site component — components/site/

Dark mode is the primary theme: design, build, and screenshot dark-first. Follow steps in order; do not skip Step 0.

**Art-direction hard gate:** `docs/design-system.md` must contain a written art direction, and read `design/taste-rules.md` (plus `design/references/` if present) before building — if the art direction section is missing, STOP and run the `art-direction` skill first.

## Step 0 — Reuse first (mandatory, must be evidenced)

Run all four checks and paste their results before creating any file. Replace `<keyword>` with 1-2 likely names for the thing (e.g. `hero`, `testimonial`, `pricing`).

```bash
grep -in "<keyword>" design/components.md
grep -rli "<keyword>" components/ui/ components/site/
ls components/site/
grep -in "<keyword>" design/patterns.md
```

Decision rules:
- **Exact match exists** → use it. This skill ends here.
- **Something close exists** (same layout with different content, or a shadcn primitive that could take a variant/prop) → **STOP and ask the user**: propose extending the existing component instead, name the file, and wait for a decision. Never fork a near-duplicate.
- **The need is a shadcn primitive that just isn't installed yet** → use the `add-shadcn-component` skill instead of this one.
- **Nothing fits** → write one line in your response before proceeding:
  `Reuse check: searched design/components.md, components/ui/, components/site/, design/patterns.md for "<keyword>" — nothing fits because <reason>.`

Also check `design/patterns.md` for a matching layout/interaction pattern (grid, card, modal, empty state). If one exists, the new component must follow it — say which pattern you're applying.

If Storybook is set up (a `storybook` script in `package.json`), also run the `storybook-component` reuse check — the MCP query over live stories catches components the greps miss. Note which source answered.

## Step 1 — Spec from two sources (never eyeball, never invent)

1. **Visual specs** (color, spacing, radius, type): come from Figma variables mapped to our tokens. Use the `from-figma` skill if a Figma link is provided. Map every Figma variable to a token in `design/tokens.json` / `design/tokens.md`. Never read values off a screenshot.
2. **Interaction behavior** (hover, focus, keyboard, aria): if the component has any interactive part, open the closest shadcn/Radix primitive's actual source in `components/ui/` and copy its focus/keyboard/aria handling. Never invent interaction patterns.

STOP and ask the user when:
- A Figma value has no matching token in `design/tokens.json` (tokens.json is protected — a PreToolUse hook blocks edits without explicit approval).
- There is no Figma spec and the user hasn't described exact visuals — ask, don't pick.
- Copy/content is missing — flag it; do not invent marketing claims.
- The component would need a new dependency.

## Step 2 — Branch

```bash
git branch --show-current   # already on a feature/* branch for this work? stay on it — don't stack a new branch
git checkout -b feature/<short-description>   # only if currently on main (or an unrelated branch)
```

Never commit to `main`.

## Step 3 — Create the file

Location: `components/site/<kebab-name>.tsx`

- File: `kebab-case.tsx` (e.g. `feature-card.tsx`)
- Component: `PascalCase` (e.g. `FeatureCard`)
- Prop type: `PascalCaseProps`, exported alongside
- Default export the component, named export the prop type

```tsx
import { cn } from "@/lib/utils";

export type FeatureCardProps = {
  title: string;
  description?: string;
  className?: string;
};

export default function FeatureCard({
  title,
  description,
  className,
}: FeatureCardProps) {
  return (
    <div className={cn("@container", className)}>
      <div className="grid grid-cols-1 @md:grid-cols-2 gap-4">
        {/* ... */}
      </div>
    </div>
  );
}
```

## Step 4 — Rules checklist

- [ ] Server Component by default. Add `"use client"` only for state, refs, effects, or browser APIs — and say why.
- [ ] Typed props — no `any`, no untyped object props.
- [ ] Accepts `className` and merges via `cn()` for layout overrides.
- [ ] Tailwind classes only — no inline styles except truly dynamic values.
- [ ] Token-only styling: semantic tokens from `design/tokens.json` (`--primary`, `--muted`, etc. per `design/tokens.md`); spacing on the Tailwind scale; radius and type on the project scales in `docs/design-system.md`. No hardcoded hex, no arbitrary px — a PostToolUse hook flags violations at write time; fix the code, never work around the hook.
- [ ] Images use `next/image` with explicit `width`, `height`, and `sizes` (reserves space → CLS ≤ 0.1).
- [ ] Comment the "why", not the "what", in non-obvious layout or interaction code.

## Step 5 — Responsive (three-layer, non-negotiable)

- [ ] Inside the component: `@container` on the wrapper, `@sm:`/`@md:` variants for internal layout. Viewport breakpoints (`sm:`/`md:`) are for page-level layout only — the section vertical-rhythm classes defined in `design/patterns.md` belong in the page/section wrapper, not deep inside a reusable component.
- [ ] Fluid typography via `clamp()` / the project type scale (`docs/design-system.md`) — no per-breakpoint font-size ladders.
- [ ] Works at 360px wide with no horizontal scroll (verified by the automated check in Step 7, not assumed).
- [ ] Tap targets ≥ 44×44px; primary CTAs 44–52px tall (shadcn defaults are app-sized — restyle up).

## Step 6 — Accessibility

- [ ] Semantic HTML (`<section>`, `<article>`, `<button>`, `<a>` — never `<div onClick>`).
- [ ] Keyboard navigable, visible focus states (taken from the shadcn/Radix source per Step 1).
- [ ] `aria-label` when a visual label is absent.
- [ ] Every animation gated on `prefers-reduced-motion` (`motion-safe:` / `motion-reduce:`).
- [ ] WCAG 2.2 AA contrast in dark mode (the primary theme).

## Step 7 — Verify with evidence ("compiles" ≠ "renders")

1. Type-check and lint — both must exit 0:

```bash
pnpm exec tsc --noEmit
pnpm lint
```

2. The component isn't used anywhere yet, so mount it on a temporary preview route `app/dev-preview/<kebab-name>/page.tsx` that renders it with realistic props. This is dev-only scaffolding, not a product page — the CLAUDE.md "stop before adding a new page not in docs/prd.md" rule does not apply, but the route must be deleted after user approval (Step 9).

3. Confirm Playwright is available: `pnpm exec playwright --version`. If it fails, Playwright is a new dependency — **STOP and ask the user** (install per `e2e-test` Step 1). If a screenshot command later errors with "Executable doesn't exist", run `npx playwright install chromium` once and retry. Then ensure the dev server is up and capture dark-mode screenshots at the three required widths:

```bash
mkdir -p .qa
curl -sf http://localhost:3000 > /dev/null || (pnpm dev > .qa/dev-server.log 2>&1 &)
for i in $(seq 1 30); do curl -sf http://localhost:3000 > /dev/null && break; sleep 2; done
curl -sf http://localhost:3000 > /dev/null || cat .qa/dev-server.log   # still down after 60s → STOP, paste the log output to the user, do not continue
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=360,800  "http://localhost:3000/dev-preview/<kebab-name>" .qa/<kebab-name>-360.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=768,900  "http://localhost:3000/dev-preview/<kebab-name>" .qa/<kebab-name>-768.png
pnpm exec playwright screenshot --color-scheme=dark --viewport-size=1440,900 "http://localhost:3000/dev-preview/<kebab-name>" .qa/<kebab-name>-1440.png
```

`--color-scheme=dark` only works when the theme follows `prefers-color-scheme`. Open each PNG before reviewing; if the background is light, the theme is class-/localStorage-based — capture with the `visual-qa` skill's `.qa/visual-capture.mjs` script instead.

4. Automated 360px no-horizontal-scroll check — must print PASS:

```bash
URL="http://localhost:3000/dev-preview/<kebab-name>" node --input-type=module -e "
import { chromium } from 'playwright';
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 360, height: 800 } });
await p.goto(process.env.URL);
const overflow = await p.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
console.log(overflow ? 'FAIL: horizontal scroll at 360px' : 'PASS: no horizontal scroll at 360px');
await b.close();"
```

If the import fails with "Cannot find package 'playwright'" but `@playwright/test` is installed, import from `@playwright/test` instead — do not add the `playwright` package (new-dependency rule).

5. Read all three screenshots yourself and review against the `visual-qa` checklist (layout integrity, hierarchy, token compliance, 44px targets). Fix and re-capture until clean — do not present broken screenshots.

The three widths above are the component-preview evidence. Once the component is placed on a real page, run the full sweep at all five standard viewports (360 / 768 / 1024 / 1440 / 1920 — test matrix in `responsive-implementation`) plus the `visual-qa` design review and the `a11y-audit` and `performance-check` skills before merge (budget: LCP ≤ 2.5s, INP ≤ 200ms, CLS ≤ 0.1, TBT < 200ms, JS first-load < 150KB gzipped — a fail means do not ship).

## Step 8 — Register in design/components.md

Add a row to the **Custom Components** table (columns: Component, File Path, Description, Props) with a one-line description and the exported props, plus a working usage example (a copy-pasteable JSX snippet with realistic props — reuse the one from the preview route). Every new component must have this entry — no orphan components.

If Storybook is set up: write the component's story in the same turn via `storybook-component` (full states matrix, dark-first). Story-per-component is part of "done", not a follow-up.

## Step 9 — Show before use

Present the three screenshots and the evidence block to the user **before** importing the component anywhere:

```
Evidence:
- Reuse check: <one-line result from Step 0>
- tsc --noEmit: exit 0 | pnpm lint: exit 0
- Screenshots: .qa/<name>-360.png, -768.png, -1440.png (dark mode)
- 360px scroll check: PASS
- Registered in design/components.md: yes (row + usage example)
```

Only after the user approves: delete `app/dev-preview/<kebab-name>/`, use the component in real pages, and commit with a conventional message (`feat: add <name> component`).
