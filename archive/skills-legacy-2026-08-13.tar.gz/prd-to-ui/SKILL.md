---
name: prd-to-ui
description: Translates a single PRD requirement (REQ-ID or named section) from docs/prd.md into a build-ready UI spec — structure, component mapping, states, responsive behavior, tokens, and acceptance checklist — directly executable by new-site-component or add-shadcn-component. Use when the user says "spec out REQ-...", "turn this requirement into UI", "PRD to UI", "design REQ-...", "what should this requirement look like", or "make a UI spec for [section]". For a whole feature spanning multiple requirements, this skill routes to design-flow instead.
---

# PRD → UI Spec (single requirement)

Turn ONE requirement into a spec a builder can execute without reading the PRD. Output goes **inline in the reply** — do NOT write a doc file unless the user explicitly asks.

## Step 0 — Scope gate

1. If the ask covers a whole feature, multiple REQ-IDs, or a full page/flow ("the whole checkout", "the dashboard"): say "This is feature-sized — use `/design-flow`; `prd-to-ui` handles one requirement at a time" and STOP (offer to run `/design-flow`).
2. If no REQ-ID or section name was given, ask which one. Never guess.

## Step 1 — Validate the requirement

1. Read `docs/prd.md`. Locate the requirement by REQ-ID (e.g. `REQ-001`) or section name. Quote it back with its file:line.
2. If it does not exist: list the REQ-IDs that DO exist and STOP.
3. Completeness check — the row must have all four: ID, Requirement, User Story ("As a…, I want…, so that…"), Acceptance Criteria. If any cell is empty or vague (no testable criteria), output a bullet list titled **"Missing from the PRD"** naming each gap, suggest the `pm` agent fills them, and STOP. Do not spec against holes.
4. Read `design/components.md`, `design/patterns.md`, and `design/tokens.md` before writing anything. Also read `docs/design-system.md` and `docs/ux-principles.md` if they exist — never contradict them.

## Step 2 — Structure (Architect thinking)

- State the element's single job in one sentence, derived from the user story — not invented.
- Element hierarchy as an ordered outline: what the user reads **first, second, third**. Justify the first read against the requirement's outcome clause ("so that…").
- CTA: what it is, where it sits, why there.
- Reference matching patterns from `design/patterns.md` by heading name (e.g. "Multi-Step Forms", "Empty States"). Do not invent a pattern that file already covers.

## Step 3 — Component mapping (reuse-first)

For every element, in this order:

1. **Existing custom component** from the Custom Components table in `design/components.md` — cite its file path.
2. **shadcn primitive** from the inventory — note it must be restyled to tokens (route install to `/add-shadcn-component`).
3. **Nothing matches** → STOP and ask before specifying a bespoke component. Present: what you searched, closest match and why it falls short (file:line evidence), and the proposed new component name. Only after approval does it enter the spec, flagged `NEW — build via new-site-component`.

Two-source rule applies to every mapped component: visuals come from Figma variables mapped to our tokens; interaction behavior comes from shadcn/Radix source. If the Figma file linked at the top of `design/components.md` has no frame for this requirement, flag it: `[FIGMA GAP — visuals unverified]`.

## Step 4 — States

Specify all five for every interactive or data-bearing element. "N/A" requires a one-line justification.

- **Empty** — per `design/patterns.md` Empty States: message + first-action CTA, never blank space
- **Loading** — Skeleton for content, in-button spinner for actions, progress bar for known duration
- **Error** — inline below field / toast / retry per the Error States pattern; every error says what happened, why, what to do
- **Success** — toast for minor, confirmation for major, always with next step
- **Edge** — long strings, zero/one/many items, offline, slow network, permission-denied as applicable

## Step 5 — Responsive (three layers)

Specify behavior at **360 / 768 / 1024 / 1440 / 1920px**, mobile-first, using all three layers:

1. Viewport breakpoints (`sm:`/`md:`…) — page-level layout shifts
2. Container queries (`@container` + `@sm:`/`@md:`) — the component itself, so it works anywhere
3. Fluid `clamp()` — typography and gradual spacing

Apply the responsive swaps from `design/patterns.md`: Dialog→Drawer on mobile, Table→cards or scroll wrapper, nav→Sheet. Every tap target ≥ 44×44px on touch (shadcn defaults are smaller — say which sizes to override).

## Step 6 — Tokens and copy

- Tokens by **semantic name only** from `design/tokens.json` / `design/tokens.md` (e.g. `color.surface.raised`) — never hex, never raw px. If a needed token doesn't exist, list it under "New tokens required" and note that adding it needs user confirmation (protected file) and `pnpm tokens` to regenerate CSS.
- Copy: pull exact strings from the PRD where they exist. Every string the PRD does not supply becomes a slot marked `[COPY NEEDED: purpose, max length]`. Never invent marketing copy.

## Step 7 — Output the spec inline

```
## UI Spec: [REQ-ID — Requirement name]
### Source            — docs/prd.md:<line>, quoted requirement + user story
### Purpose           — one sentence
### Structure         — ordered hierarchy with first/second/third read + CTA
### Component Mapping — | Element | Component | Source (file path / shadcn / NEW) | Variant | Notes |
### States            — | Element | Empty | Loading | Error | Success | Edge |
### Responsive        — | Width (360/768/1024/1440/1920) | Layout | Layer used |
### Tokens            — | Element | Color | Typography | Spacing/Radius |
### Copy Slots        — every [COPY NEEDED] item in one list
### Acceptance Checklist
```

The acceptance checklist inherits the REQ's own acceptance criteria verbatim, then appends the standard gates:

- [ ] Each PRD acceptance criterion (copied, one checkbox each)
- [ ] Dark mode first; verified at 360/768/1024/1440/1920px
- [ ] Tap targets ≥ 44×44px; keyboard nav + visible focus; WCAG 2.2 AA contrast
- [ ] `prefers-reduced-motion` respected for any animation
- [ ] Token-only styling — zero hardcoded hex/px (design-system-guard will catch violations)
- [ ] No CLS from images/fonts/dynamic content; perf budget LCP ≤ 2.5s / INP ≤ 200ms / TBT < 200ms / CLS ≤ 0.1 / JS < 150KB gz
- [ ] Verified rendered, not just compiled — screenshot evidence via visual-qa

## Step 8 — Hand off

End with the exact next command(s): `/add-shadcn-component <name>` for primitives to install, `/new-site-component <name>` for approved bespoke pieces, `/write-tickets` if the user wants it tracked. If any `[COPY NEEDED]` or `[FIGMA GAP]` flags remain, list them as blockers the user must resolve before build. Do not start building — this skill ends at the spec.
