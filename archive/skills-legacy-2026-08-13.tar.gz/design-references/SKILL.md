---
name: design-references
description: Turns design inspiration into durable, buildable reference material in design/references/ — captures screenshots, extracts transferable observations, and maintains the reference index. Use when the user shares a site or design they love, asks to "save this as a reference," "add this to references," "capture this site," "here's some inspiration," "look at this design," or drops screenshots to file. Runs before or alongside art-direction so visual builds can cite concrete references instead of vibes. (A figma.com link shared to be implemented as code is from-figma; deciding the project's own aesthetic from these references is art-direction; logging a correction to our own output is taste-retro.)
---

# design-references — the reference pipeline

Turn "I love this site" into evidence another session can build from. Output lives in `design/references/`; other skills (`from-figma`, `new-site-component`, `design-flow`, `art-direction`) read it before visual work.

## Folder convention (create if missing)

```
design/references/
  README.md            # the index — one table row per reference
  <slug>/              # kebab-case, e.g. linear-pricing, stripe-docs
    360-dark.png       # screenshots, named <width>-<theme>.png
    1440-dark.png
    notes.md           # transferable observations + the user's WHY
```

Index table columns in `README.md` — this matches the header the template ships with (create with this header if absent; if the file exists, keep its header as-is):

```markdown
| Slug | Source | Added | Why the user loves it | Notes |
|---|---|---|---|---|
| linear-pricing | https://linear.app/pricing | 2026-07-08 | "calm density — nothing shouts" | [notes](linear-pricing/notes.md) |
```

- The shipped README contains a `| _none yet_ |` placeholder row — replace it with your first real row instead of appending below it.
- `Added` date comes from `date +%F` — never guess the date.
- Slug rule: `<site>-<page-or-section>`, kebab-case (`linear-pricing`, `stripe-docs`). If the surface has no obvious page name, ask rather than invent one.

## Step 0 — Orient

1. `mkdir -p "design/references"` and read `design/references/README.md` if it exists — never duplicate a slug; if the URL is already indexed, ask whether to update or skip.
2. Read `docs/design-system.md` (art direction) and `design/taste-rules.md` if they exist. You will check new references against them in Step 4.

## Step 1 — Intake (three paths)

### Path A: user gives a URL — capture it YOURSELF with Playwright

Full-page, at 360 and 1440, in whatever theme(s) the site actually presents (most references here are dark; capture light too only if the site offers it):

```bash
mkdir -p "design/references/<slug>"
npx playwright screenshot --color-scheme dark --viewport-size "360,800" --full-page <url> "design/references/<slug>/360-dark.png"
npx playwright screenshot --color-scheme dark --viewport-size "1440,900" --full-page <url> "design/references/<slug>/1440-dark.png"
```

If the site also presents a light theme worth keeping, repeat with `--color-scheme light` and save as `.../360-light.png` and `.../1440-light.png`.

- If only the Chromium browser is missing (`Executable doesn't exist` / `browserType.launch` error but `@playwright/test` is in `package.json`): run `pnpm exec playwright install chromium` and retry. If the `@playwright/test` package itself is missing, that is a new dependency — **STOP and ask** per CLAUDE.md before installing it (the `e2e-test` skill has the exact commands); projects that have run `visual-qa` or `e2e-test` already have it.
- If the site is WebGL/canvas/animation-heavy: a static capture likely misses the point. Say so explicitly and ask the user for the frames or a screen recording of the moments that matter. File whatever they provide; do not pretend the flat screenshot represents the site.
- STOP: site unreachable (timeout, auth wall, bot block) → do not guess from memory. Ask the user for screenshots and proceed via Path B.

Open the captured PNGs with the Read tool and look at them before writing notes — notes describe what you observed, not what the URL implies.

### Path B: user drops images manually

Copy/move them into `design/references/<slug>/`, rename to `<width>-<theme>.png` when the width is known (otherwise keep a descriptive name like `hero-dark.png`). Ask for the source URL if not given; record "provided by user" for capture provenance.

### Path C: Mobbin (optional, never blocking)

Probe first:

```bash
npx -y @aos-engineer/mobbin-mcp skill doctor '{}'
```

- If it errors, is not installed, or reports unauthenticated → fall back to Path A/B without complaint. Never block intake on Mobbin.
- If healthy → use it to fetch the requested app/flow screens, save them into `design/references/<slug>/`, and note "source: Mobbin" in notes.md.

## Step 2 — Get the user's WHY

Ask: "In one line — what do you love about this?" Record the answer **verbatim** (quoted) in both notes.md and the index table. If they already said it, quote what they said. Do not paraphrase and do not skip this — the WHY is the most durable part of the reference.

## Step 3 — Write notes.md (transferable observations only)

Every reference gets `design/references/<slug>/notes.md`. Rule: **measurable and specific, never "looks clean / modern / premium."** Each observation must be something a builder could act on without seeing the screenshot. Template:

```markdown
# <slug>

- **Source:** <url> — captured <date> at 360/1440, dark
- **Why (user, verbatim):** "<one line>"

## Transferable observations
- **Type scale:** approx. ratio and anchor sizes (e.g. ~1.25 ratio, body ~16px, hero ~56px; one weight change per level, not two)
- **Spacing rhythm:** base unit and section cadence (e.g. 8px grid; ~120px between sections at 1440, ~64px at 360)
- **Color story:** neutrals count, surface layering, accent discipline (e.g. one accent hue, used only on primary CTA and links — nowhere else)
- **Layout moves:** the 2-3 structural ideas worth stealing (e.g. asymmetric 5/7 split hero; sticky left rail collapses to top tabs at <768)
- **Hierarchy techniques:** how attention is directed (size vs weight vs color vs whitespace — which does the heavy lifting)
- **Motion character:** duration/easing feel and what moves (e.g. 150-200ms ease-out on hover only; no scroll animation)

## Do NOT copy
- Anything here that conflicts with our art direction or taste rules (see Step 4)
```

Fill every section; write "not observable from capture" rather than inventing. Reference our token names from `design/tokens.json` when mapping a color story ("their accent role ≈ our `--color-accent`") — never introduce hex values as targets.

## Step 4 — Check against art direction, then index

1. Compare notes against `docs/design-system.md` and `design/taste-rules.md`.
   - STOP: a reference contradicts the written art direction or a taste rule → surface the conflict to the user ("this reference uses 3 accent hues; our art direction says one — keep as reference with a Do-NOT-copy note, or revisit the art direction?"). Never silently pick a side, and never silently edit the art direction.
2. Append the row to `design/references/README.md` (create the file with the table header if it's the first reference).
3. Report with evidence: list the exact files written (`design/references/<slug>/...`) and the index row added. "Saved" without file paths is not done — `verify-before-done` applies.

## Builder rule (contract with other skills)

Stated here so every skill honors it: **before any visual build work, read `design/references/README.md` and the notes.md files relevant to the surface being built.** Every visual build report must cite which reference each section follows (`hero → linear-pricing: 5/7 split, single accent`), or explicitly state "no reference" for that section and flag it as a taste risk. If `design/references/` is empty when a visual build starts, say so and suggest running this skill first.
