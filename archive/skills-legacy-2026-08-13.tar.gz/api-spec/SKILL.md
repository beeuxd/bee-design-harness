---
name: api-spec
description: Defines API contracts (endpoints, TypeScript request/response shapes, data models, auth rules) for a feature so the frontend can build against mocks and a backend team can implement independently, writing the result to docs/api-spec.md. Contract-only — it never implements server code in this repo. Use when the user says "define the API", "API spec", "what endpoints do we need", "API contract", "data model for this feature", or "spec this for the backend team".
---

# API Spec — contract for a feature

Goal: a developer-ready contract in `docs/api-spec.md` that the frontend can mock against today and a backend team can implement without asking questions. This skill produces a document, not code. If a `backend-dev` agent exists in `.claude/agents/`, you may delegate the drafting to it — the steps and quality bar below still apply.

## Hard rules

- **Contract only.** Do NOT create route handlers, server code, or database code in this repo. The only file you write is `docs/api-spec.md`.
- **Never invent requirements.** Every endpoint must trace to a requirement ID in `docs/prd.md` or a step in `docs/user-flows.md`. No trace = no endpoint.
- **Evidence over claims.** Cite sources as `file:line` (e.g. `docs/prd.md:24 REQ-001`) next to each endpoint.
- **Content-first.** Do not invent enum values, copy strings, or business rules. Unknown = Open Question, not a guess.

## Step 1 — Scope and inputs

1. Confirm which feature(s) to spec. If the user named one, use it; otherwise ask.
2. Read, in order:
   - `docs/prd.md` — requirement IDs, personas, in/out of scope
   - `docs/user-flows.md` — every step, error state, and edge case
   - `docs/tech.md` — stack conventions (Server/Client component split matters for the consumption notes in Step 4)
   - `docs/api-spec.md` if it already exists — you are extending it, not clobbering it. Preserve existing sections; add or update only the feature at hand.
3. **STOP and ask** — do not proceed — if any of these hold:
   - `docs/prd.md` has no filled-in requirements for this feature (template tables still empty)
   - `docs/user-flows.md` has no flow covering this feature
   - Personas/roles are undefined but the feature clearly needs authorization rules
   - The user asks for endpoints not backed by any documented requirement
   Report exactly what is missing and which file:line you checked. Suggest running `/prd-to-ui` or `/flow-map` first if the gap is upstream.

## Step 2 — Inventory every data touchpoint

Walk each relevant flow in `docs/user-flows.md` step by step and list every point where the UI:
- **reads** data (page load, list, detail, search, filter, poll)
- **writes** data (create, update, delete, submit, upload)
- needs **derived/aggregate** data (counts, statuses, dashboards)

For each touchpoint record: flow name + step, screen/component that needs it, and the UI states the flow defines (loading / empty / error / success). This inventory drives Step 3 — an endpoint with no touchpoint is invented; a touchpoint with no endpoint is a gap.

## Step 3 — Define the contract

For **every endpoint**, specify all of:

1. **Method + path** — REST conventions, plural nouns, kebab-case: `GET /api/projects/{projectId}/members`
2. **Auth requirement** — public / authenticated / role-restricted (name the role from the PRD personas)
3. **Request shape** — path params, query params, and body as a TypeScript type. No `any`.
4. **Response shape** — TypeScript type. It MUST cover every UI state the flows define:
   - list endpoints: the empty case must be representable (`items: []` plus whatever the empty state needs, e.g. `total: 0`)
   - detail views: include every field the UI renders — check the flow's "user sees" lines
   - if the UI shows partial/degraded states, the shape must express them
5. **Error responses** — one shared error shape for the whole API, e.g.:
   ```ts
   type ApiError = { error: { code: string; message: string; details?: Record<string, string> } };
   ```
   Per endpoint, list applicable status codes (400 validation, 401 unauthenticated, 403 forbidden, 404 not found, 409 conflict where relevant) and the `code` values the frontend branches on. Every error row in the flow's Error States table must map to a status + code.
6. **Pagination** — required on every list endpoint. Pick one style for the whole API (cursor-based preferred: `?cursor=&limit=`, response `{ items: T[]; nextCursor: string | null; total?: number }`) and use it consistently.
7. **Trace** — the `file:line` requirement/flow step this endpoint serves.
8. **Frontend consumption notes** (carried from the flows):
   - which screen/component consumes it
   - blocks render (fetch in Server Component) vs loads async (Client) — use the decision tree in `docs/tech.md`; if that file is missing or has no such guidance, write "stack conventions undocumented" for this line and record the gap under Open Questions — do not guess
   - optimistic update opportunity? (toggles, renames, reorders — yes; payments, destructive actions — no)
   - loading / empty / error state implications

Then define **data models**: each entity as a TypeScript type with field types, nullability, and relations (`userId: string // -> User.id`). Use ISO-8601 strings for dates, string IDs. Models are the single source — endpoint types reference them (`Pick`, `Omit`, arrays), never redeclare fields.

Then write **authorization notes per role**: a role × capability table (who can read/create/update/delete each entity), derived from PRD personas. If a rule is not derivable from the docs, it goes in Open Questions — do not guess.

## Step 4 — Write docs/api-spec.md

Structure (create the file with this skeleton if it doesn't exist; otherwise merge your feature in):

```md
# API Specification
> Contract only. No server implementation lives in this repo.
> Status: draft | reviewed. Last updated: <date>, feature: <name>

## Conventions        (base path, auth scheme, error shape, pagination style)
## Data Models        (TypeScript types + relations)
## Authorization      (role × capability table)
## Endpoints — <Feature name>
### <METHOD> <path>   (one subsection per endpoint, all 8 items from Step 3)
## Open Questions for Backend
```

Open Questions must be explicit and answerable, each with the blocked endpoint(s): e.g. "Is member removal soft-delete or hard-delete? Blocks: DELETE /api/projects/{id}/members/{memberId} — affects whether 410 vs 404 is returned after removal."

## Step 5 — Verify before done

Run the checklist and show the result (this is the `verify-before-done` evidence):

- [ ] Every Step 2 touchpoint has an endpoint; every endpoint has a trace (`file:line`)
- [ ] Every list endpoint has pagination; every response shape covers the empty state
- [ ] Every error row in the flows' Error States tables maps to a status code + error code
- [ ] Every endpoint has an auth requirement; every role in the PRD appears in the authorization table
- [ ] Zero `any`; endpoint types reference the data models
- [ ] All unknowns are in Open Questions — none silently resolved
- [ ] No file other than `docs/api-spec.md` was created or modified

Gaps you cannot close from the docs: list them under Open Questions and tell the user — do not pad the spec. If stuck after 2 attempts at reconciling docs, follow `escalation-protocol`.

## Handoff

Tell the user: the spec is at `docs/api-spec.md`; next steps are typically `write-tickets` (turn the contract into GitHub Issues) or building the UI against mocks typed directly from the spec's data models. Do not commit — if the user asks to, use a `feature/<slug>` branch, never `main`.
