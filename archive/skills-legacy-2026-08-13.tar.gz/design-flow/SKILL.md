---
name: design-flow
description: Turns PRD requirements for one feature into a single implementable design spec at docs/specs/<feature-slug>.md by chaining an Architect lens (IA, flows, hierarchy, responsive) and a UI lens (component mapping, tokens, states, copy flags). Use when the user says "design this feature", "design flow for X", "create a design spec", "spec out the UI for X", "how should this screen be structured", or "turn the PRD into a design". Requirements must already exist in docs/prd.md — if they do not, route to the kickoff skill instead of inventing them. (Specing one single REQ-ID is prd-to-ui; exploring several visual directions before committing is design-options — this skill specs a whole feature once the direction is set.)
---

# design-flow — PRD requirements → one implementable design spec

Goal: produce `docs/specs/<feature-slug>.md` so complete that the `from-figma` or `new-site-component` skills can build it with **zero further design decisions**. Every claim in the spec needs a source (`file:line` or doc section) — evidence over claims.

## Step 0 — Precondition gate

1. Read `docs/prd.md`. Find the requirement rows (REQ-xxx) for the feature named in the request.
2. If the PRD has no filled-in requirements for this feature (empty tables, or the feature is absent): **STOP.** Say "No requirements for <feature> in docs/prd.md — run the `kickoff` skill first," and do nothing else.
3. If the feature adds a page not listed in `docs/prd.md`: **STOP and ask** — house rule, no new pages without approval.
4. Check that `docs/design-system.md` contains an art direction section. If it does not: **STOP.** Say "No art direction in docs/design-system.md — run the `art-direction` skill first," and do nothing else. No visual work without direction — house rule.
5. Read, in order: `docs/ux-principles.md`, `design/patterns.md`, `design/components.md`, `design/tokens.md` (semantic token names), `docs/design-system.md`, `design/taste-rules.md`. Do not proceed from memory of these files. If any of them is missing: **STOP and ask**, naming the missing file — never substitute assumptions for a prerequisite doc.
6. Derive `<feature-slug>` (kebab-case, e.g. "Team Billing" → `team-billing`). Check for an existing spec: `ls "docs/specs/" 2>/dev/null || echo "no specs yet"`. If `docs/specs/<feature-slug>.md` exists, ask whether to revise it or start fresh — never silently overwrite.
7. **Optional upstream inputs:** if `docs/ideation/wireframes.md` has a validated matrix for this feature's screens (from `wireframe-loop`), the spec's structure sections start from those frames — cite the frame links and don't contradict the validated region layout without flagging it. If `docs/ideation/feature-tree.md` exists, cite FEAT-IDs alongside REQ-IDs so the trace chain stays unbroken.

## Step 1 — Architect lens (structure the experience)

Work through these in order; cite the PRD requirement ID that justifies each decision.

1. **Single job per page/section.** One sentence each: hook, prove, teach, or convert (per `docs/ux-principles.md` §1). If you cannot state the job in one sentence, split or cut the section — do not proceed with a diffuse screen.
2. **Information architecture.** Page/section outline, navigation placement, where this feature lives in the existing site structure.
3. **User flow.** Happy path step-by-step, PLUS every error and edge branch: validation failure, network failure, permission denied, empty data, partial data. Each branch ends in a defined screen state — no dead ends. Every error tells the user what happened, why, and what to do next (`design/patterns.md` → Error States). If the flow has more than ~6 screens or forks heavily, note that the `flow-map` skill can diagram it — but the spec text must still enumerate every branch.
4. **Visual hierarchy.** For each screen: what is read first, second, third, and why the order matches the screen's job. The first viewport (mobile and desktop) must signal purpose and show a CTA or clear path to one.
5. **Responsive behavior.** Describe the layout at all five widths — 360 / 768 / 1024 / 1440 / 1920px — mobile-first (360 is the base, wider widths are enhancements). Use the three-layer system: viewport breakpoints for page layout, `@container` queries for reusable components, `clamp()` for fluid type. Reference stacking rules from `design/patterns.md` → Responsive Stacking rather than inventing new ones. **No layout shift:** every image, embed, and dynamic block gets reserved dimensions or an aspect ratio in the spec — CLS ≤ 0.1 is a shipping gate (performance budget in `docs/tech.md`).
6. **CTA placement + rationale.** Name the outcome in the CTA label (never "Submit"/"Click here"). Primary CTAs 44–52px tall.
7. **Motion opportunities.** Purposeful only; every one must respect `prefers-reduced-motion` and fit the performance budget in `docs/tech.md` (the `performance-check` skill gates it). Point to the `motion` skill for implementation.
8. Check every proposed structure against `docs/ux-principles.md` → Anti-Patterns. If a PRD requirement forces an anti-pattern (e.g. asks for an auto-advancing carousel): **STOP and ask**, citing the anti-pattern line.

## Step 2 — UI lens (apply the visual system)

1. **Map EVERY element to a component** in `design/components.md` — the shadcn inventory, the Custom Components table, and the Figma-to-Code mapping. Reuse before build; extending an existing component beats creating a new one.
2. **Unmapped element = STOP.** Do not invent a component. Present exactly three options and wait for the answer:
   - (a) closest existing component and what compromise it implies,
   - (b) a variant of an existing component (name the component + new variant),
   - (c) a genuinely new component (justify why nothing existing can be extended).
3. **Two-source rule per component:** visual specs come from Figma variables mapped to project tokens (if a Figma file is linked in `design/components.md`, verify against it — the `from-figma` and `design-tokens-sync` skills handle the mechanics); interaction behavior comes from shadcn/Radix source, never guessed.
4. **Token usage by semantic name only** (e.g. `color.surface.raised`, `space.md`) from `design/tokens.json` / `design/tokens.md`. No hex, no raw px. Dark mode is the primary theme — spec dark first. If a needed token does not exist: **STOP and ask** — `design/tokens.json` is a protected file; if approved, the token change goes through `design-tokens-sync` and `pnpm tokens`, never a hand edit.
5. **States matrix.** For each screen, define all of: empty, loading, error, success, edge (long text, 0/1/many items, offline, slow network). Pick loading treatment per `design/patterns.md`: skeleton for content, spinner-in-button for actions, progress bar for known duration. Empty states get a message + primary CTA, never blank space.
6. **Copy.** Never invent marketing copy or user-facing claims. Mark every missing string inline as `[COPY NEEDED: what it must communicate, max length]`. Microcopy that is purely functional (button labels naming outcomes, error text) may be drafted but flagged `[DRAFT COPY]` for `ux-copy-review`.
7. **Accessibility.** Per screen: keyboard path, focus order, visible focus rings, ARIA where semantics fall short, contrast AA against the dark theme, 44×44px minimum tap targets, color never the only status indicator. WCAG 2.2 AA is the floor, not the target.

## Step 3 — Write the spec

Write `docs/specs/<feature-slug>.md` (create `docs/specs/` if missing) with exactly these sections:

```markdown
# Design Spec: <Feature Name>
Source requirements: REQ-xxx, REQ-yyy (docs/prd.md)

## 1. Architecture          — page/section jobs, IA, navigation
## 2. User Flow             — happy path + every error/edge branch
## 3. Visual Hierarchy      — first/second/third read per screen
## 4. Responsive Specs      — table: 360 / 768 / 1024 / 1440 / 1920px per screen
## 5. Component Map         — table: Element | Component (source file/inventory row) | Variant | Key tokens
## 6. States Matrix         — table: Screen | Empty | Loading | Error | Success | Edge
## 7. Copy Inventory        — every [COPY NEEDED] / [DRAFT COPY] item in one list
## 8. Accessibility         — keyboard, focus, ARIA, contrast, motion notes
## 9. Motion                — purposeful animations + reduced-motion behavior
## 10. Open Questions       — anything unresolved, with who must answer
```

Rules for the file:
- Every component row cites its source (`design/components.md` row or component file path). Every color/space/radius value is a semantic token name.
- Every image, embed, and dynamic-content element carries reserved dimensions or an aspect ratio (no layout shift — CLS ≤ 0.1 per `docs/tech.md`).
- If section 10 contains a question that blocks implementation, say so explicitly at the top of the spec: `STATUS: BLOCKED — see Open Questions`. Otherwise `STATUS: READY FOR BUILD`.
- The test of done: a builder running `from-figma` or `new-site-component` from this spec should never need to make a design decision. Re-read the spec asking "where would I have to guess?" — fix every guess point before finishing.

## Step 4 — Hand off

1. Show the user the spec path and a 5-line summary: screens, component count (existing / variant / new), copy items needed, open questions.
2. Suggest next steps in order: resolve Open Questions → `write-tickets` (if using the kanban flow) → build via `from-figma` (Figma design exists) or `new-site-component` (bespoke) → gates: `visual-qa`, `a11y-audit`, `review-ux`, `performance-check`.
3. Do not start building. This skill ends at the spec.
