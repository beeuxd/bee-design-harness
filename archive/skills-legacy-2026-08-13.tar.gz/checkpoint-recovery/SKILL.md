---
name: checkpoint-recovery
description: Creates git checkpoint commits before risky changes and walks through exact recovery commands when something breaks — restore, revert, reflog, or stash — without ever using destructive git operations. Use before editing shared components, changing dependencies, refactoring more than 2 files, or touching lib/ or components/ui/, and whenever work is broken or missing. Trigger phrases — "make a checkpoint," "undo this," "roll it back," "restore the last checkpoint," "I lost my work," "git is in a weird state." (Diagnosing why something broke is debugging-protocol; this skill restores a known-good state.)
---

# Checkpoint & recovery — git safety net

Git is the undo system for this whole project. This skill has two halves: **checkpoint BEFORE risk** and **recover AFTER damage**. Never improvise git commands outside this file.

## Part 1 — Checkpoint before any risky change

### What counts as risky (if ANY apply, checkpoint first)

- [ ] Editing a shared component (anything in `components/ui/` or imported by 2+ files)
- [ ] Adding, removing, or upgrading a dependency (`pnpm add` / `pnpm remove` / `pnpm up`)
- [ ] A refactor touching more than 2 files
- [ ] Anything in `lib/`
- [ ] Codemods, find-and-replace across files, or config changes (`tailwind.config`, `next.config`, `tsconfig`)

Note: `design/tokens.json` and `CLAUDE.md` are protected files — a PreToolUse hook blocks edits without explicit user approval. Checkpointing does not grant that approval.

### Checkpoint procedure

1. Confirm you are on a feature branch, never `main`:
   ```bash
   git branch --show-current
   ```
   If it prints `main`, STOP. Create a branch first: `git checkout -b feature/short-description` (per CLAUDE.md conventions).
2. Make the checkpoint commit:
   ```bash
   git add -A && git commit -m 'checkpoint: before <what you are about to do>'
   ```
   Example: `checkpoint: before upgrading tailwind to v4`.
   If git replies "nothing to commit, working tree clean", that is not an error — the tree is already fully committed and the current HEAD *is* your checkpoint. Skip to step 3 and record its sha.
3. Get the checkpoint sha with `git log --oneline -1` and state it in your reply to the user (e.g., "Checkpoint made: `a1b2c3d`"). This is the "return here" point — it must be visible in the conversation, not just in your head.
4. Proceed with the risky change in small verifiable steps. After it works and is verified (dark mode, 360/768/1024/1440/1920px — sweep script in `responsive-implementation`, design review in `visual-qa`), make a real conventional commit (`feat:`/`fix:`/`refactor:`). Checkpoint commits can stay in history; they are harmless.

If a checkpoint would sweep in unrelated half-done work, tell the user what `git status` shows and ask whether to include it or `git stash` it first.

## Part 2 — Inspect before you touch anything

When something seems wrong, look first. These commands are read-only and always safe:

```bash
git status                 # what's modified, staged, untracked
git diff                   # exact uncommitted changes, line by line
git diff --stat            # same, summarized per file — good first look
git log --oneline -10      # last 10 commits with short shas
```

Read the output. Identify which situation below you are in BEFORE running any recovery command. If the situation doesn't clearly match exactly one branch of the tree, STOP: paste the `git status` output to the user in plain language and ask which state they want to return to.

## Part 3 — Recovery decision tree

### A. Bad work that is NOT committed yet ("undo what I just did")

`git status` shows modified files; the bad changes are not in any commit.

- One file:
  ```bash
  git restore path/to/file.tsx
  ```
- Everything uncommitted:
  ```bash
  git restore .
  ```
- If `git status` shows changes under "Changes to be committed" (staged), plain `git restore` will NOT touch them. Discard staged + unstaged together:
  ```bash
  git restore --staged --worktree path/to/file.tsx   # one file
  git restore --staged --worktree .                  # everything
  ```
- Untracked (brand-new) files are never removed by `git restore`. If a new file itself is the bad work, delete it explicitly (`rm path/to/file.tsx`) after confirming with the user — name the exact file first.

**Warning — say this to the user before running it:** `git restore` permanently DISCARDS uncommitted changes in those files. They are not recoverable afterward. Confirm with the user if the discarded changes include anything they might want (run `git diff` and summarize what will be lost).

### B. Bad work that IS committed ("that commit broke it")

1. Find the bad commit: `git log --oneline -10`.
2. Undo it with a new commit (history stays intact — safe even if pushed):
   ```bash
   git revert <sha>
   ```
3. If revert reports conflicts, do NOT resolve by guessing. Run `git revert --abort`, show the user the conflict list, and ask.
4. If git says the commit "is a merge but no -m option was given," STOP — reverting a merge commit needs a parent choice that must not be guessed. Show the user the error and the output of `git log --oneline -5`, and ask.

**Never use `git reset --hard` on anything that has been pushed.** `revert` adds an "undo" commit; `reset --hard` erases history and destroys teammates' ability to pull.

### C. "I lost work" — it existed, now it's gone

Committed work is almost never truly lost. Walk the reflog:

1. ```bash
   git reflog -20
   ```
   This lists every state HEAD has been in, newest first, with shas — including commits that no longer appear in `git log`.
2. Find the entry whose message matches the lost work (e.g., the checkpoint message, or `commit: feat: ...`).
3. Verify before restoring — look, don't leap:
   ```bash
   git show --stat <sha>        # which files that state touched
   git diff HEAD <sha> --stat   # how it differs from now
   ```
4. Recover it as a NEW branch so nothing current is overwritten. First make sure `git status` is clean — if it isn't, park current changes with `git stash push -u -m 'parking: before recovery'` so they don't get mixed into the recovered state. Then:
   ```bash
   git branch recovered-work <sha>
   git checkout recovered-work
   ```
   If git says `recovered-work` already exists (a previous recovery used the name), do NOT delete or reuse it — pick a fresh name, e.g. `recovered-work-2` or `recovered-work-<short-description>` (`git branch --list 'recovered-work*'` shows what's taken).
5. Show the user the recovered files and ask how to merge them back.

If nothing in the reflog matches, STOP and tell the user exactly what you searched and what you found. Do not "fix" it by recreating the work silently.

### D. "Weird state" — detached HEAD, mid-merge, mid-rebase, unexplained files

1. Run `git status` and read the first lines — git names the state ("HEAD detached at...", "You are currently reverting...", "All conflicts fixed but you are still merging").
2. If status shows an in-progress operation, run the matching `--abort` FIRST (`git merge --abort`, `git rebase --abort`, `git revert --abort`) — it returns everything to the pre-operation state. Tell the user which abort you're running and why before running it. Do NOT try to stash first: `git stash` fails with "needs merge" errors while conflicted files exist, and the abort already restores the pre-operation state.
3. If there is NO in-progress operation but there are uncommitted or unexplained changes, park them safely:
   ```bash
   git stash push -u -m 'parking: <what this is>'
   ```
   `-u` includes untracked (brand-new) files, which stash otherwise skips. Stash is a shelf, not a trash can — restore later with `git stash list` then `git stash pop`.
4. Detached HEAD with work you want to keep? Attach it to a branch before doing anything else: `git switch -c rescue/<short-description>`.
5. Still unclear after that? STOP. Paste `git status` output to the user, explain in plain language what you think happened, and ask before proceeding.

## Hard rules — no exceptions

1. **Never force-push.** No `git push --force`, no `--force-with-lease`. If push is rejected, STOP and show the user the error.
2. **Never `git reset --hard`** unless BOTH are true: the target commit is a checkpoint made today (verify with `git log --oneline -10`), AND nothing being discarded was pushed. When either is false or unknown, use `git revert` or STOP.
3. **Never delete or edit the `.git` directory.** Not for "fixing corruption," not for anything. If git itself errors, STOP and show the user.
4. **Never commit to `main`.** All work happens on `feature/short-description` branches.
5. **When unsure which recovery branch applies, STOP** — show the user the `git status` output, explain the options in plain language (this user is not a developer; say "this discards your unsaved edits," not "this resets the working tree"), and wait for their choice.

## Evidence requirements

After any recovery, prove the repo is healthy — "no git errors" is not evidence:

- [ ] `git status` shows a clean or expected state (paste it)
- [ ] `git log --oneline -5` shows the expected history (paste it)
- [ ] `pnpm build` (or the dev server) succeeds — compiles
- [ ] The affected page/component actually renders — verify visually per the `visual-qa` skill, dark mode first
- [ ] If the recovery was mid-feature, summarize what state the work is in now and what the next step is (or use `handoff-summary` if the session is ending)
